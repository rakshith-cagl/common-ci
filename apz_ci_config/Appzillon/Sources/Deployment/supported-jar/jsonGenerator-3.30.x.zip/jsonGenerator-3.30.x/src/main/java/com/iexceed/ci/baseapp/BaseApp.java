
package com.iexceed.ci.baseapp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "typeclass",
    "name",
    "type",
    "childs",
    "firstpage",
    "dfltlang",
    "litprefix",
    "encryptionreqd",
    "dflttheme",
    "dfltenv",
    "appid",
    "currentversion",
    "baseversion",
    "appicon",
    "apptype",
    "microapptype",
    "appdisplayname",
    "appversion",
    "appexpirydate",
    "serverurl",
    "generateotp",
    "otarequired",
    "auditlogreqd",
    "sendlog",
    "loglevel",
    "noofloglines",
    "preventscreenshot",
    "tracklocation",
    "otprequired",
    "otpchanel",
    "otplength",
    "authenticationtype",
    "certificatepinning",
    "idletimeoutinsecconds",
    "bindingengine",
    "dataintegrity",
    "savepwd",
    "jsfiles_list"
})
public class BaseApp {

    @Override
	public String toString() {
		return "BaseApp [typeclass=" + typeclass + ", name=" + name + ", type=" + type + ", childs=" + childs
				+ ", firstpage=" + firstpage + ", dfltlang=" + dfltlang + ", litprefix=" + litprefix
				+ ", encryptionreqd=" + encryptionreqd + ", dflttheme=" + dflttheme + ", dfltenv=" + dfltenv
				+ ", appid=" + appid + ", currentversion=" + currentversion + ", baseversion=" + baseversion
				+ ", appicon=" + appicon + ", apptype=" + apptype + ", microapptype=" + microapptype
				+ ", appdisplayname=" + appdisplayname + ", appversion=" + appversion + ", appexpirydate="
				+ appexpirydate + ", serverurl=" + serverurl + ", generateotp=" + generateotp + ", otarequired="
				+ otarequired + ", auditlogreqd=" + auditlogreqd + ", sendlog=" + sendlog + ", loglevel=" + loglevel
				+ ", noofloglines=" + noofloglines + ", preventscreenshot=" + preventscreenshot + ", tracklocation="
				+ tracklocation + ", otprequired=" + otprequired + ", otpchanel=" + otpchanel + ", otplength="
				+ otplength + ", authenticationtype=" + authenticationtype + ", certificatepinning="
				+ certificatepinning + ", idletimeoutinsecconds=" + idletimeoutinsecconds + ", bindingengine="
				+ bindingengine + ", dataintegrity=" + dataintegrity + ", savepwd=" + savepwd + ", jsfilesList="
				+ jsfilesList + ", additionalProperties=" + additionalProperties + "]";
	}

	@JsonProperty("typeclass")
    private String typeclass;
    @JsonProperty("name")
    private String name;
    @JsonProperty("type")
    private String type;
    @JsonProperty("childs")
    private List<Object> childs = null;
    @JsonProperty("firstpage")
    private String firstpage;
    @JsonProperty("dfltlang")
    private String dfltlang;
    @JsonProperty("litprefix")
    private String litprefix;
    @JsonProperty("encryptionreqd")
    private String encryptionreqd;
    @JsonProperty("dflttheme")
    private String dflttheme;
    @JsonProperty("dfltenv")
    private String dfltenv;
    @JsonProperty("appid")
    private String appid;
    @JsonProperty("currentversion")
    private String currentversion;
    @JsonProperty("baseversion")
    private String baseversion;
    @JsonProperty("appicon")
    private String appicon;
    @JsonProperty("apptype")
    private String apptype;
    @JsonProperty("microapptype")
    private String microapptype;
    @JsonProperty("appdisplayname")
    private String appdisplayname;
    @JsonProperty("appversion")
    private String appversion;
    @JsonProperty("appexpirydate")
    private String appexpirydate;
    @JsonProperty("serverurl")
    private String serverurl;
    @JsonProperty("generateotp")
    private String generateotp;
    @JsonProperty("otarequired")
    private String otarequired;
    @JsonProperty("auditlogreqd")
    private String auditlogreqd;
    @JsonProperty("sendlog")
    private String sendlog;
    @JsonProperty("loglevel")
    private String loglevel;
    @JsonProperty("noofloglines")
    private String noofloglines;
    @JsonProperty("preventscreenshot")
    private String preventscreenshot;
    @JsonProperty("tracklocation")
    private String tracklocation;
    @JsonProperty("otprequired")
    private String otprequired;
    @JsonProperty("otpchanel")
    private String otpchanel;
    @JsonProperty("otplength")
    private String otplength;
    @JsonProperty("authenticationtype")
    private String authenticationtype;
    @JsonProperty("certificatepinning")
    private String certificatepinning;
    @JsonProperty("idletimeoutinsecconds")
    private String idletimeoutinsecconds;
    @JsonProperty("bindingengine")
    private String bindingengine;
    @JsonProperty("dataintegrity")
    private String dataintegrity;
    @JsonProperty("savepwd")
    private String savepwd;
    @JsonProperty("jsfiles_list")
    private List<String> jsfilesList = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("typeclass")
    public String getTypeclass() {
        return typeclass;
    }

    @JsonProperty("typeclass")
    public void setTypeclass(String typeclass) {
        this.typeclass = typeclass;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("childs")
    public List<Object> getChilds() {
        return childs;
    }

    @JsonProperty("childs")
    public void setChilds(List<Object> childs) {
        this.childs = childs;
    }

    @JsonProperty("firstpage")
    public String getFirstpage() {
        return firstpage;
    }

    @JsonProperty("firstpage")
    public void setFirstpage(String firstpage) {
        this.firstpage = firstpage;
    }

    @JsonProperty("dfltlang")
    public String getDfltlang() {
        return dfltlang;
    }

    @JsonProperty("dfltlang")
    public void setDfltlang(String dfltlang) {
        this.dfltlang = dfltlang;
    }

    @JsonProperty("litprefix")
    public String getLitprefix() {
        return litprefix;
    }

    @JsonProperty("litprefix")
    public void setLitprefix(String litprefix) {
        this.litprefix = litprefix;
    }

    @JsonProperty("encryptionreqd")
    public String getEncryptionreqd() {
        return encryptionreqd;
    }

    @JsonProperty("encryptionreqd")
    public void setEncryptionreqd(String encryptionreqd) {
        this.encryptionreqd = encryptionreqd;
    }

    @JsonProperty("dflttheme")
    public String getDflttheme() {
        return dflttheme;
    }

    @JsonProperty("dflttheme")
    public void setDflttheme(String dflttheme) {
        this.dflttheme = dflttheme;
    }

    @JsonProperty("dfltenv")
    public String getDfltenv() {
        return dfltenv;
    }

    @JsonProperty("dfltenv")
    public void setDfltenv(String dfltenv) {
        this.dfltenv = dfltenv;
    }

    @JsonProperty("appid")
    public String getAppid() {
        return appid;
    }

    @JsonProperty("appid")
    public void setAppid(String appid) {
        this.appid = appid;
    }

    @JsonProperty("currentversion")
    public String getCurrentversion() {
        return currentversion;
    }

    @JsonProperty("currentversion")
    public void setCurrentversion(String currentversion) {
        this.currentversion = currentversion;
    }

    @JsonProperty("baseversion")
    public String getBaseversion() {
        return baseversion;
    }

    @JsonProperty("baseversion")
    public void setBaseversion(String baseversion) {
        this.baseversion = baseversion;
    }

    @JsonProperty("appicon")
    public String getAppicon() {
        return appicon;
    }

    @JsonProperty("appicon")
    public void setAppicon(String appicon) {
        this.appicon = appicon;
    }

    @JsonProperty("apptype")
    public String getApptype() {
        return apptype;
    }

    @JsonProperty("apptype")
    public void setApptype(String apptype) {
        this.apptype = apptype;
    }

    @JsonProperty("microapptype")
    public String getMicroapptype() {
        return microapptype;
    }

    @JsonProperty("microapptype")
    public void setMicroapptype(String microapptype) {
        this.microapptype = microapptype;
    }

    @JsonProperty("appdisplayname")
    public String getAppdisplayname() {
        return appdisplayname;
    }

    @JsonProperty("appdisplayname")
    public void setAppdisplayname(String appdisplayname) {
        this.appdisplayname = appdisplayname;
    }

    @JsonProperty("appversion")
    public String getAppversion() {
        return appversion;
    }

    @JsonProperty("appversion")
    public void setAppversion(String appversion) {
        this.appversion = appversion;
    }

    @JsonProperty("appexpirydate")
    public String getAppexpirydate() {
        return appexpirydate;
    }

    @JsonProperty("appexpirydate")
    public void setAppexpirydate(String appexpirydate) {
        this.appexpirydate = appexpirydate;
    }

    @JsonProperty("serverurl")
    public String getServerurl() {
        return serverurl;
    }

    @JsonProperty("serverurl")
    public void setServerurl(String serverurl) {
        this.serverurl = serverurl;
    }

    @JsonProperty("generateotp")
    public String getGenerateotp() {
        return generateotp;
    }

    @JsonProperty("generateotp")
    public void setGenerateotp(String generateotp) {
        this.generateotp = generateotp;
    }

    @JsonProperty("otarequired")
    public String getOtarequired() {
        return otarequired;
    }

    @JsonProperty("otarequired")
    public void setOtarequired(String otarequired) {
        this.otarequired = otarequired;
    }

    @JsonProperty("auditlogreqd")
    public String getAuditlogreqd() {
        return auditlogreqd;
    }

    @JsonProperty("auditlogreqd")
    public void setAuditlogreqd(String auditlogreqd) {
        this.auditlogreqd = auditlogreqd;
    }

    @JsonProperty("sendlog")
    public String getSendlog() {
        return sendlog;
    }

    @JsonProperty("sendlog")
    public void setSendlog(String sendlog) {
        this.sendlog = sendlog;
    }

    @JsonProperty("loglevel")
    public String getLoglevel() {
        return loglevel;
    }

    @JsonProperty("loglevel")
    public void setLoglevel(String loglevel) {
        this.loglevel = loglevel;
    }

    @JsonProperty("noofloglines")
    public String getNoofloglines() {
        return noofloglines;
    }

    @JsonProperty("noofloglines")
    public void setNoofloglines(String noofloglines) {
        this.noofloglines = noofloglines;
    }

    @JsonProperty("preventscreenshot")
    public String getPreventscreenshot() {
        return preventscreenshot;
    }

    @JsonProperty("preventscreenshot")
    public void setPreventscreenshot(String preventscreenshot) {
        this.preventscreenshot = preventscreenshot;
    }

    @JsonProperty("tracklocation")
    public String getTracklocation() {
        return tracklocation;
    }

    @JsonProperty("tracklocation")
    public void setTracklocation(String tracklocation) {
        this.tracklocation = tracklocation;
    }

    @JsonProperty("otprequired")
    public String getOtprequired() {
        return otprequired;
    }

    @JsonProperty("otprequired")
    public void setOtprequired(String otprequired) {
        this.otprequired = otprequired;
    }

    @JsonProperty("otpchanel")
    public String getOtpchanel() {
        return otpchanel;
    }

    @JsonProperty("otpchanel")
    public void setOtpchanel(String otpchanel) {
        this.otpchanel = otpchanel;
    }

    @JsonProperty("otplength")
    public String getOtplength() {
        return otplength;
    }

    @JsonProperty("otplength")
    public void setOtplength(String otplength) {
        this.otplength = otplength;
    }

    @JsonProperty("authenticationtype")
    public String getAuthenticationtype() {
        return authenticationtype;
    }

    @JsonProperty("authenticationtype")
    public void setAuthenticationtype(String authenticationtype) {
        this.authenticationtype = authenticationtype;
    }

    @JsonProperty("certificatepinning")
    public String getCertificatepinning() {
        return certificatepinning;
    }

    @JsonProperty("certificatepinning")
    public void setCertificatepinning(String certificatepinning) {
        this.certificatepinning = certificatepinning;
    }

    @JsonProperty("idletimeoutinsecconds")
    public String getIdletimeoutinsecconds() {
        return idletimeoutinsecconds;
    }

    @JsonProperty("idletimeoutinsecconds")
    public void setIdletimeoutinsecconds(String idletimeoutinsecconds) {
        this.idletimeoutinsecconds = idletimeoutinsecconds;
    }

    @JsonProperty("bindingengine")
    public String getBindingengine() {
        return bindingengine;
    }

    @JsonProperty("bindingengine")
    public void setBindingengine(String bindingengine) {
        this.bindingengine = bindingengine;
    }

    @JsonProperty("dataintegrity")
    public String getDataintegrity() {
        return dataintegrity;
    }

    @JsonProperty("dataintegrity")
    public void setDataintegrity(String dataintegrity) {
        this.dataintegrity = dataintegrity;
    }

    @JsonProperty("savepwd")
    public String getSavepwd() {
        return savepwd;
    }

    @JsonProperty("savepwd")
    public void setSavepwd(String savepwd) {
        this.savepwd = savepwd;
    }

    @JsonProperty("jsfiles_list")
    public List<String> getJsfilesList() {
        return jsfilesList;
    }

    @JsonProperty("jsfiles_list")
    public void setJsfilesList(List<String> jsfilesList) {
        this.jsfilesList = jsfilesList;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
