package com.iexceed.ci.generatefile;

import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iexceed.ci.androidpreference.AndroidPref;
import com.iexceed.ci.baseapp.BaseApp;
import com.iexceed.ci.environment.Environment;
import com.iexceed.ci.iospreference.IosPref;
import com.iexceed.ci.jenkinsrelatedproperties.JenkinsProperties;
import com.iexceed.ci.languages.Languages;
import com.iexceed.ci.microappdtls.MicroAppMain;
import com.iexceed.ci.serverpreference.ServerPreference;
import com.iexceed.ci.webpreference.WebPref;

public class PropertiesDtls {
	static ObjectMapper mapper = new ObjectMapper();
	private String projectFilePath;
	private String baseAppName;
	private String buildMode;
	private JenkinsProperties objJenkinsProp;
	private BaseApp objBaseApp;
	private MicroAppMain objMicroApp;
	private Environment objEnvProp;
	private WebPref objWebOSProp;
	private ServerPreference objServerPrefProp;
	private String baseAppPropFilePath;
	private String microAppPropFilePath;
	private String envPropFilePath;
	private String webOsFilePath;
	private String serverPrefFilePath;
	private String androidPrefFilePath;
	private AndroidPref objAndroidProp;
	private String iosPrefFilePath;
	private IosPref objIosProp;
	private String langsPrefFilePath;
	private Languages objLangsProp;
	private String serverBaseApps;
	private String jenkinsUiPath;

	public PropertiesDtls(String projectFilePath, String baseAppName, String buildMode,
			JenkinsProperties objJenkinsProp, String baseAppPropFilePath, String microAppPropFilePath,
			String envPropFilePath, String webOsFilePath, String serverPrefFilePath, String androidPrefFilePath,  String iosPrefFilePath, String includeMicroApp,
			String langsPrefFilePath, String serverBaseApps, String jenkinsUiPath) {

		super();
		try {
			this.projectFilePath = projectFilePath;
			this.baseAppName = baseAppName;
			this.buildMode = buildMode;
			this.objJenkinsProp = objJenkinsProp;
			this.baseAppPropFilePath = baseAppPropFilePath;
			this.microAppPropFilePath = microAppPropFilePath;
			this.envPropFilePath = envPropFilePath;
			this.webOsFilePath = webOsFilePath;
			this.androidPrefFilePath = androidPrefFilePath;
			this.iosPrefFilePath = iosPrefFilePath;
			this.langsPrefFilePath = langsPrefFilePath;
			this.serverPrefFilePath = serverPrefFilePath;
			this.objBaseApp = mapper.readValue(new File(this.baseAppPropFilePath), BaseApp.class);
			if("Y".equalsIgnoreCase(includeMicroApp)) {
				this.objMicroApp = mapper.readValue(new File(this.microAppPropFilePath), MicroAppMain.class);
			}
			this.objEnvProp = mapper.readValue(new File(this.envPropFilePath), Environment.class);
			this.objLangsProp = mapper.readValue(new File(this.langsPrefFilePath), Languages.class);
			this.objWebOSProp = mapper.readValue(new File(this.webOsFilePath), WebPref.class);
			this.objServerPrefProp = mapper.readValue(new File(this.serverPrefFilePath), ServerPreference.class);
			this.objAndroidProp = mapper.readValue(new File(this.androidPrefFilePath), AndroidPref.class);
			this.objIosProp = mapper.readValue(new File(this.iosPrefFilePath), IosPref.class);
			this.serverBaseApps = serverBaseApps;
			this.jenkinsUiPath = jenkinsUiPath;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getAndroidPrefFilePath() {
		return androidPrefFilePath;
	}

	public void setAndroidPrefFilePath(String androidPrefFilePath) {
		this.androidPrefFilePath = androidPrefFilePath;
	}

	public Object getObjAndroidProp() {
		return objAndroidProp;
	}

	public void setObjAndroidProp(AndroidPref objAndroidProp) {
		this.objAndroidProp = objAndroidProp;
	}
	
	public String getIosPrefFilePath() {
		return iosPrefFilePath;
	}

	public void setIosPrefFilePath(String iosPrefFilePath) {
		this.iosPrefFilePath = iosPrefFilePath;
	}

	public Object getObjIosProp() {
		return objIosProp;
	}

	public void setObjIosProp(IosPref objIosProp) {
		this.objIosProp = objIosProp;
	}

	public String getBaseAppName() {
		return baseAppName;
	}

	public String getProjectFilePath() {
		return projectFilePath;
	}

	public void setProjectFilePath(String projectFilePath) {
		this.projectFilePath = projectFilePath;
	}

	public void setBaseAppName(String baseAppName) {
		this.baseAppName = baseAppName;
	}

	public String getBuildMode() {
		return buildMode;
	}

	public void setBuildMode(String buildMode) {
		this.buildMode = buildMode;
	}

	public JenkinsProperties getObjJenkinsProp() {
		return objJenkinsProp;
	}

	public void setObjJenkinsProp(JenkinsProperties objJenkinsProp) {
		this.objJenkinsProp = objJenkinsProp;
	}

	public BaseApp getObjBaseApp() {
		return objBaseApp;
	}

	public void setObjBaseApp(BaseApp objBaseApp) {
		this.objBaseApp = objBaseApp;
	}

	public MicroAppMain getObjMicroApp() {
		return objMicroApp;
	}

	public void setObjMicroApp(MicroAppMain objMicroApp) {
		this.objMicroApp = objMicroApp;
	}

	public Environment getObjEnvProp() {
		return objEnvProp;
	}

	public void setObjEnvProp(Environment objEnvProp) {
		this.objEnvProp = objEnvProp;
	}

	public WebPref getObjWebOSProp() {
		return objWebOSProp;
	}

	public void setObjWebOSProp(WebPref objWebOSProp) {
		this.objWebOSProp = objWebOSProp;
	}

	public ServerPreference getObjServerPrefProp() {
		return objServerPrefProp;
	}

	public void setObjServerPrefProp(ServerPreference objServerPrefProp) {
		this.objServerPrefProp = objServerPrefProp;
	}

	public String getServerBaseApps() {
		return serverBaseApps;
	}

	public void setServerBaseApps(String serverBaseApps) {
		this.serverBaseApps = serverBaseApps;
	}
	
	public String getJenkinsUiPath() {
		return jenkinsUiPath;
	}

	public void setJenkinsUiPath(String jenkinsUiPath) {
		this.jenkinsUiPath = jenkinsUiPath;
	}
	
	public String getLanguagesPrefFilePath() {
		return langsPrefFilePath;
	}

	public void setLanguagesPrefFilePath(String langsPrefFilePath) {
		this.langsPrefFilePath = langsPrefFilePath;
	}

	public Languages getObjLangsProp() {
		return objLangsProp;
	}

	public void setObjLangsProp(Languages objLangsProp) {
		this.objLangsProp = objLangsProp;
	}
}