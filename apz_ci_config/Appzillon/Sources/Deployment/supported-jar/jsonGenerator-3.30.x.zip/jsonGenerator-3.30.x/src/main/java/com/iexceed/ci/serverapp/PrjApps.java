
package com.iexceed.ci.serverapp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.JsonNode;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
   
})
public class PrjApps {

    @JsonProperty("AxisBaseApp")
    private JsonNode axisBaseApp = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("AxisBaseApp")
    public JsonNode getAxisBaseApp() {
        return axisBaseApp;
    }

    @Override
	public String toString() {
		return "PrjApps [axisBaseApp=" + axisBaseApp + ", additionalProperties=" + additionalProperties + "]";
	}

	@JsonProperty("AxisBaseApp")
    public void setAxisBaseApp(JsonNode axisBaseApp) {
        this.axisBaseApp = axisBaseApp;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
