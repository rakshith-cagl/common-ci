
package com.iexceed.ci.serverapp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.JsonNode;
import com.iexceed.ci.buildapp.App;
import com.iexceed.ci.buildapp.Envobj;
import com.iexceed.ci.environment.Environment;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "user",
    "status",
    "rebuildstatus",
    "buildfolder",
    "buildmode",
    "dataintegrity",
    "prjApps",
    "envobj",
    "apps",
    "oss"
})
public class BuildServer {

    @Override
	public String toString() {
		return "BuildServer [user=" + user + ", status=" + status + ", rebuildstatus=" + rebuildstatus
				+ ", buildfolder=" + buildfolder + ", buildmode=" + buildmode + ", prjApps=" + prjApps + ", envobj="
				+ envobj + ", apps=" + apps + ", oss=" + oss + ", additionalProperties=" + additionalProperties + "]";
	}

	@JsonProperty("user")
    private String user;
    @JsonProperty("status")
    private String status;
    @JsonProperty("rebuildstatus")
    private String rebuildstatus;
    @JsonProperty("buildfolder")
    private String buildfolder;
    @JsonProperty("buildmode")
    private String buildmode;
    @JsonProperty("dataintegrity")
    private String dataintegrity;
    @JsonProperty("prjApps")
    private JsonNode  prjApps;
    @JsonProperty("envobj")
    private Environment envobj;
    @JsonProperty("apps")
    private List<App> apps = null;
    @JsonProperty("oss")
    private List<OsServer> oss = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("user")
    public String getUser() {
        return user;
    }

    @JsonProperty("user")
    public void setUser(String user) {
        this.user = user;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("rebuildstatus")
    public String getRebuildstatus() {
        return rebuildstatus;
    }

    @JsonProperty("rebuildstatus")
    public void setRebuildstatus(String rebuildstatus) {
        this.rebuildstatus = rebuildstatus;
    }

    @JsonProperty("buildfolder")
    public String getBuildfolder() {
        return buildfolder;
    }

    @JsonProperty("buildfolder")
    public void setBuildfolder(String buildfolder) {
        this.buildfolder = buildfolder;
    }

    @JsonProperty("buildmode")
    public String getBuildmode() {
        return buildmode;
    }

    @JsonProperty("buildmode")
    public void setBuildmode(String buildmode) {
        this.buildmode = buildmode;
    }
    
    @JsonProperty("dataintegrity")
    public String getDataintegrity() {
        return dataintegrity;
    }

    @JsonProperty("dataintegrity")
    public void setDataintegrity(String dataintegrity) {
        this.dataintegrity = dataintegrity;
    }
    
    @JsonProperty("prjApps")
    public JsonNode getPrjApps() {
        return prjApps;
    }

    @JsonProperty("prjApps")
    public void setPrjApps(JsonNode prjApps) {
        this.prjApps = prjApps;
    }

    @JsonProperty("envobj")
    public Environment getEnvobj() {
        return envobj;
    }

    @JsonProperty("envobj")
    public void setEnvobj(Environment environment) {
        this.envobj = environment;
    }

    @JsonProperty("apps")
    public List<App> getApps() {
        return apps;
    }

    @JsonProperty("apps")
    public void setApps(List<App> apps) {
        this.apps = apps;
    }

    @JsonProperty("oss")
    public List<OsServer> getOss() {
        return oss;
    }

    @JsonProperty("oss")
    public void setOss(List<OsServer> oss) {
        this.oss = oss;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
