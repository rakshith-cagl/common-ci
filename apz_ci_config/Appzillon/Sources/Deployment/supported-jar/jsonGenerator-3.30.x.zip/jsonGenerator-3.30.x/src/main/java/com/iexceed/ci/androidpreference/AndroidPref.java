
package com.iexceed.ci.androidpreference;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "typeclass",
    "name",
    "type",
    "childs",
    "andbundleid",
    "andkeystore",
    "andkeystorepswrd",
    "andkeystorealias",
    "andkeystorealiaspswrd",
    "andappversion",
    "andappversioncode",
    "andobfuscation",
    "andstatusbarcolor",
    "andsplashscreencolor",
    "andinternalsandbox",
    "andexternalsandbox",
    "andextralargepoicon",
    "andlargepoicon",
    "andnormalpoicon",
    "andsmallpoicon"
})
public class AndroidPref {

    @JsonProperty("typeclass")
    private String typeclass;
    @JsonProperty("name")
    private String name;
    @JsonProperty("type")
    private String type;
    @JsonProperty("childs")
    private List<Object> childs = null;
    @JsonProperty("andbundleid")
    private String andbundleid;
    @JsonProperty("andkeystore")
    private String andkeystore;
    @JsonProperty("andkeystorepswrd")
    private String andkeystorepswrd;
    @JsonProperty("andkeystorealias")
    private String andkeystorealias;
    @JsonProperty("andkeystorealiaspswrd")
    private String andkeystorealiaspswrd;
    @JsonProperty("andappversion")
    private String andappversion;
    @JsonProperty("andappversioncode")
    private String andappversioncode;
    @JsonProperty("andobfuscation")
    private String andobfuscation;
    @JsonProperty("andstatusbarcolor")
    private String andstatusbarcolor;
    @JsonProperty("andsplashscreencolor")
    private String andsplashscreencolor;
    @JsonProperty("andinternalsandbox")
    private String andinternalsandbox;
    @JsonProperty("andexternalsandbox")
    private String andexternalsandbox;
    @JsonProperty("andextralargepoicon")
    private String andextralargepoicon;
    @JsonProperty("andlargepoicon")
    private String andlargepoicon;
    @JsonProperty("andnormalpoicon")
    private String andnormalpoicon;
    @JsonProperty("andsmallpoicon")
    private String andsmallpoicon;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("typeclass")
    public String getTypeclass() {
        return typeclass;
    }

    @JsonProperty("typeclass")
    public void setTypeclass(String typeclass) {
        this.typeclass = typeclass;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("childs")
    public List<Object> getChilds() {
        return childs;
    }

    @JsonProperty("childs")
    public void setChilds(List<Object> childs) {
        this.childs = childs;
    }

    @JsonProperty("andbundleid")
    public String getAndbundleid() {
        return andbundleid;
    }

    @JsonProperty("andbundleid")
    public void setAndbundleid(String andbundleid) {
        this.andbundleid = andbundleid;
    }

    @JsonProperty("andkeystore")
    public String getAndkeystore() {
        return andkeystore;
    }

    @JsonProperty("andkeystore")
    public void setAndkeystore(String andkeystore) {
        this.andkeystore = andkeystore;
    }

    @JsonProperty("andkeystorepswrd")
    public String getAndkeystorepswrd() {
        return andkeystorepswrd;
    }

    @JsonProperty("andkeystorepswrd")
    public void setAndkeystorepswrd(String andkeystorepswrd) {
        this.andkeystorepswrd = andkeystorepswrd;
    }

    @JsonProperty("andkeystorealias")
    public String getAndkeystorealias() {
        return andkeystorealias;
    }

    @JsonProperty("andkeystorealias")
    public void setAndkeystorealias(String andkeystorealias) {
        this.andkeystorealias = andkeystorealias;
    }

    @JsonProperty("andkeystorealiaspswrd")
    public String getAndkeystorealiaspswrd() {
        return andkeystorealiaspswrd;
    }

    @JsonProperty("andkeystorealiaspswrd")
    public void setAndkeystorealiaspswrd(String andkeystorealiaspswrd) {
        this.andkeystorealiaspswrd = andkeystorealiaspswrd;
    }

    @JsonProperty("andappversion")
    public String getAndappversion() {
        return andappversion;
    }

    @JsonProperty("andappversion")
    public void setAndappversion(String andappversion) {
        this.andappversion = andappversion;
    }

    @JsonProperty("andappversioncode")
    public String getAndappversioncode() {
        return andappversioncode;
    }

    @JsonProperty("andappversioncode")
    public void setAndappversioncode(String andappversioncode) {
        this.andappversioncode = andappversioncode;
    }

    @JsonProperty("andobfuscation")
    public String getAndobfuscation() {
        return andobfuscation;
    }

    @JsonProperty("andobfuscation")
    public void setAndobfuscation(String andobfuscation) {
        this.andobfuscation = andobfuscation;
    }

    @JsonProperty("andstatusbarcolor")
    public String getAndstatusbarcolor() {
        return andstatusbarcolor;
    }

    @JsonProperty("andstatusbarcolor")
    public void setAndstatusbarcolor(String andstatusbarcolor) {
        this.andstatusbarcolor = andstatusbarcolor;
    }

    @JsonProperty("andsplashscreencolor")
    public String getAndsplashscreencolor() {
        return andsplashscreencolor;
    }

    @JsonProperty("andsplashscreencolor")
    public void setAndsplashscreencolor(String andsplashscreencolor) {
        this.andsplashscreencolor = andsplashscreencolor;
    }

    @JsonProperty("andinternalsandbox")
    public String getAndinternalsandbox() {
        return andinternalsandbox;
    }

    @JsonProperty("andinternalsandbox")
    public void setAndinternalsandbox(String andinternalsandbox) {
        this.andinternalsandbox = andinternalsandbox;
    }

    @JsonProperty("andexternalsandbox")
    public String getAndexternalsandbox() {
        return andexternalsandbox;
    }

    @JsonProperty("andexternalsandbox")
    public void setAndexternalsandbox(String andexternalsandbox) {
        this.andexternalsandbox = andexternalsandbox;
    }

    @JsonProperty("andextralargepoicon")
    public String getAndextralargepoicon() {
        return andextralargepoicon;
    }

    @JsonProperty("andextralargepoicon")
    public void setAndextralargepoicon(String andextralargepoicon) {
        this.andextralargepoicon = andextralargepoicon;
    }

    @JsonProperty("andlargepoicon")
    public String getAndlargepoicon() {
        return andlargepoicon;
    }

    @JsonProperty("andlargepoicon")
    public void setAndlargepoicon(String andlargepoicon) {
        this.andlargepoicon = andlargepoicon;
    }

    @JsonProperty("andnormalpoicon")
    public String getAndnormalpoicon() {
        return andnormalpoicon;
    }

    @JsonProperty("andnormalpoicon")
    public void setAndnormalpoicon(String andnormalpoicon) {
        this.andnormalpoicon = andnormalpoicon;
    }

    @JsonProperty("andsmallpoicon")
    public String getAndsmallpoicon() {
        return andsmallpoicon;
    }

    @JsonProperty("andsmallpoicon")
    public void setAndsmallpoicon(String andsmallpoicon) {
        this.andsmallpoicon = andsmallpoicon;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}