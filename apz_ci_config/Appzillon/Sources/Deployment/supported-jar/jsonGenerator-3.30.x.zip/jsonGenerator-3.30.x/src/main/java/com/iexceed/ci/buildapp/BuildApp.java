
package com.iexceed.ci.buildapp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iexceed.ci.environment.Environment;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "user",
    "status",
    "simulator",
    "serverurl",
    "buildfolder",
    "preLoadDependencies",
    "loadAllOnStartup",
    "buildmode",
    "dataintegrity",
    "encryptionreqd",
    "envobj",
    "enablemockserver",
    "publicKey",
    "langs",
    "oss",
    "apps"
})
public class BuildApp {

    @Override
	public String toString() {
		return "BuildApp [user=" + user + ", status=" + status + ", simulator=" + simulator + ", serverurl=" + serverurl
				+ ", buildfolder=" + buildfolder + ", preLoadDependencies=" + preLoadDependencies
				+ ", loadAllOnStartup=" + loadAllOnStartup + ", buildmode=" + buildmode + ", envobj=" + envobj
				+ ", enablemockserver=" + enablemockserver + ", publicKey=" + publicKey + ", langs=" + langs + ", oss="
				+ oss + ", apps=" + apps + ", additionalProperties=" + additionalProperties + "]";
	}

	@JsonProperty("user")
    private String user;
    @JsonProperty("status")
    private String status;
    @JsonProperty("simulator")
    private Boolean simulator;
    @JsonProperty("serverurl")
    private String serverurl;
    @JsonProperty("buildfolder")
    private String buildfolder;
    @JsonProperty("preLoadDependencies")
    private Boolean preLoadDependencies;
    @JsonProperty("loadAllOnStartup")
    private Boolean loadAllOnStartup;
    @JsonProperty("buildmode")
    private String buildmode;
    @JsonProperty("encryptionreqd")
    private String encryptionreqd;
	@JsonProperty("dataintegrity")
    private String dataintegrity;
    @JsonProperty("envobj")
    private Environment envobj;
    @JsonProperty("enablemockserver")
    private Boolean enablemockserver;
    @JsonProperty("publicKey")
    private String publicKey;
    @JsonProperty("langs")
    private List<String> langs = null;
    @JsonProperty("oss")
    private List<Os> oss = null;
    @JsonProperty("apps")
    private List<App> apps = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("dataintegrity")
    public String getDataintegrity() {
		return dataintegrity;
	}
    @JsonProperty("dataintegrity")
	public void setDataintegrity(String dataintegrity) {
		this.dataintegrity = dataintegrity;
	}

    @JsonProperty("encryptionreqd")
    public String getEncryptionreqd() {
        return encryptionreqd;
    }

    @JsonProperty("encryptionreqd")
    public void setEncryptionreqd(String encryptionreqd) {
        this.encryptionreqd = encryptionreqd;
    }
    
    @JsonProperty("user")
    public String getUser() {
        return user;
    }

    @JsonProperty("user")
    public void setUser(String user) {
        this.user = user;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("simulator")
    public Boolean getSimulator() {
        return simulator;
    }

    @JsonProperty("simulator")
    public void setSimulator(Boolean simulator) {
        this.simulator = simulator;
    }

    @JsonProperty("serverurl")
    public String getServerurl() {
        return serverurl;
    }

    @JsonProperty("serverurl")
    public void setServerurl(String serverurl) {
        this.serverurl = serverurl;
    }

    @JsonProperty("buildfolder")
    public String getBuildfolder() {
        return buildfolder;
    }

    @JsonProperty("buildfolder")
    public void setBuildfolder(String buildfolder) {
        this.buildfolder = buildfolder;
    }

    @JsonProperty("preLoadDependencies")
    public Boolean getPreLoadDependencies() {
        return preLoadDependencies;
    }

    @JsonProperty("preLoadDependencies")
    public void setPreLoadDependencies(Boolean preLoadDependencies) {
        this.preLoadDependencies = preLoadDependencies;
    }

    @JsonProperty("loadAllOnStartup")
    public Boolean getLoadAllOnStartup() {
        return loadAllOnStartup;
    }

    @JsonProperty("loadAllOnStartup")
    public void setLoadAllOnStartup(Boolean loadAllOnStartup) {
        this.loadAllOnStartup = loadAllOnStartup;
    }

    @JsonProperty("buildmode")
    public String getBuildmode() {
        return buildmode;
    }

    @JsonProperty("buildmode")
    public void setBuildmode(String buildmode) {
        this.buildmode = buildmode;
    }

    @JsonProperty("envobj")
    public Environment getEnvobj() {
        return envobj;
    }

    @JsonProperty("envobj")
    public void setEnvobj(Environment envobj) {
        this.envobj = envobj;
    }

    @JsonProperty("enablemockserver")
    public Boolean getEnablemockserver() {
        return enablemockserver;
    }

    @JsonProperty("enablemockserver")
    public void setEnablemockserver(Boolean enablemockserver) {
        this.enablemockserver = enablemockserver;
    }

    @JsonProperty("publicKey")
    public String getPublicKey() {
        return publicKey;
    }

    @JsonProperty("publicKey")
    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }

    @JsonProperty("langs")
    public List<String> getLangs() {
        return langs;
    }

    @JsonProperty("langs")
    public void setLangs(List<String> langs) {
        this.langs = langs;
    }

    @JsonProperty("oss")
    public List<Os> getOss() {
        return oss;
    }

    @JsonProperty("oss")
    public void setOss(List<Os> list) {
        this.oss = list;
    }

    @JsonProperty("apps")
    public List<App> getApps() {
        return apps;
    }

    @JsonProperty("apps")
    public void setApps(List<App> apps) {
        this.apps = apps;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}