
package com.iexceed.ci.serverapp;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "name",
    "typeclass",
    "state",
    "status",
    "appservertype",
    "admindbtype",
    "appdbtype",
    "warfilename",
    "serverurl",
    "logpath",
    "logginglevel",
    "bundleserverprops",
    "genconvhtml",
    "metadatadsn",
    "admindsn",
    "staticanalyzer",
    "enablemonitoring",
    "httpkeystorepath",
    "httpkeystorepwd",
    "httpkeypwd",
    "truststorepath",
    "truststorepwd",
    "smsport",
    "devicedestinationport",
    "privateKey"
})
public class OsServer {

    @Override
	public String toString() {
		return "Os [name=" + name + ", typeclass=" + typeclass + ", state=" + state + ", status=" + status
				+ ", appservertype=" + appservertype + ", admindbtype=" + admindbtype + ", appdbtype=" + appdbtype
				+ ", warfilename=" + warfilename + ", serverurl=" + serverurl + ", logpath=" + logpath
				+ ", logginglevel=" + logginglevel + ", bundleserverprops=" + bundleserverprops + ", genconvhtml="
				+ genconvhtml + ", metadatadsn=" + metadatadsn + ", admindsn=" + admindsn + ", staticanalyzer="
				+ staticanalyzer + ", enablemonitoring=" + enablemonitoring + ", httpkeystorepath=" + httpkeystorepath
				+ ", httpkeystorepwd=" + httpkeystorepwd + ", httpkeypwd=" + httpkeypwd + ", truststorepath="
				+ truststorepath + ", truststorepwd=" + truststorepwd + ", smsport=" + smsport
				+ ", devicedestinationport=" + devicedestinationport + ", privateKey=" + privateKey
				+ ", additionalProperties=" + additionalProperties + "]";
	}

	public String getTypeoflogging() {
		return typeoflogging;
	}

	public void setTypeoflogging(String typeoflogging) {
		this.typeoflogging = typeoflogging;
	}

	public String getRolloverlog() {
		return rolloverlog;
	}

	public void setRolloverlog(String rolloverlog) {
		this.rolloverlog = rolloverlog;
	}

	public String getLogfilemaxsize() {
		return logfilemaxsize;
	}

	public void setLogfilemaxsize(String logfilemaxsize) {
		this.logfilemaxsize = logfilemaxsize;
	}

	public String getDefrolloverstrategy() {
		return defrolloverstrategy;
	}

	public void setDefrolloverstrategy(String defrolloverstrategy) {
		this.defrolloverstrategy = defrolloverstrategy;
	}

	public String getKafkatopic() {
		return kafkatopic;
	}

	public void setKafkatopic(String kafkatopic) {
		this.kafkatopic = kafkatopic;
	}

	public String getKafkaservers() {
		return kafkaservers;
	}

	public void setKafkaservers(String kafkaservers) {
		this.kafkaservers = kafkaservers;
	}

	public String getMaxramalloc() {
		return maxramalloc;
	}

	public void setMaxramalloc(String maxramalloc) {
		this.maxramalloc = maxramalloc;
	}

	public String getRecordbatchsize() {
		return recordbatchsize;
	}

	public void setRecordbatchsize(String recordbatchsize) {
		this.recordbatchsize = recordbatchsize;
	}

	public String getMultitenancy() {
		return multitenancy;
	}

	public void setMultitenancy(String multitenancy) {
		this.multitenancy = multitenancy;
	}

	public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}

	@JsonProperty("name")
    private String name;
    @JsonProperty("typeclass")
    private String typeclass;
    @JsonProperty("state")
    private String state;
    @JsonProperty("status")
    private String status;
    @JsonProperty("appservertype")
    private String appservertype;
    @JsonProperty("admindbtype")
    private String admindbtype;
    @JsonProperty("appdbtype")
    private String appdbtype;
    @JsonProperty("warfilename")
    private String warfilename;
    @JsonProperty("serverurl")
    private String serverurl;
    @JsonProperty("logpath")
    private String logpath;
    @JsonProperty("logginglevel")
    private String logginglevel;
    @JsonProperty("bundleserverprops")
    private String bundleserverprops;
    @JsonProperty("genconvhtml")
    private String genconvhtml;
    @JsonProperty("metadatadsn")
    private String metadatadsn;
    @JsonProperty("admindsn")
    private String admindsn;
    @JsonProperty("staticanalyzer")
    private Boolean staticanalyzer;
    @JsonProperty("enablemonitoring")
    private Boolean enablemonitoring;
    @JsonProperty("httpkeystorepath")
    private String httpkeystorepath;
    @JsonProperty("httpkeystorepwd")
    private String httpkeystorepwd;
    @JsonProperty("httpkeypwd")
    private String httpkeypwd;
    @JsonProperty("truststorepath")
    private String truststorepath;
    @JsonProperty("truststorepwd")
    private String truststorepwd;
    @JsonProperty("smsport")
    private String smsport;
    @JsonProperty("devicedestinationport")
    private String devicedestinationport;
    @JsonProperty("privateKey")
    private String privateKey;
    @JsonProperty("typeoflogging")
    private String typeoflogging;
    @JsonProperty("rolloverlog")
    private String rolloverlog;
    @JsonProperty("logfilemaxsize")
    private String logfilemaxsize;
    @JsonProperty("defrolloverstrategy")
    private String defrolloverstrategy;
    @JsonProperty("kafkatopic")
    private String kafkatopic;
    @JsonProperty("kafkaservers")
    private String kafkaservers;
    @JsonProperty("maxramalloc")
    private String maxramalloc;
    @JsonProperty("recordbatchsize")
    private String recordbatchsize;
    @JsonProperty("multitenancy")
    private String multitenancy;
    
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("typeclass")
    public String getTypeclass() {
        return typeclass;
    }

    @JsonProperty("typeclass")
    public void setTypeclass(String typeclass) {
        this.typeclass = typeclass;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("appservertype")
    public String getAppservertype() {
        return appservertype;
    }

    @JsonProperty("appservertype")
    public void setAppservertype(String appservertype) {
        this.appservertype = appservertype;
    }

    @JsonProperty("admindbtype")
    public String getAdmindbtype() {
        return admindbtype;
    }

    @JsonProperty("admindbtype")
    public void setAdmindbtype(String admindbtype) {
        this.admindbtype = admindbtype;
    }

    @JsonProperty("appdbtype")
    public String getAppdbtype() {
        return appdbtype;
    }

    @JsonProperty("appdbtype")
    public void setAppdbtype(String appdbtype) {
        this.appdbtype = appdbtype;
    }

    @JsonProperty("warfilename")
    public String getWarfilename() {
        return warfilename;
    }

    @JsonProperty("warfilename")
    public void setWarfilename(String warfilename) {
        this.warfilename = warfilename;
    }

    @JsonProperty("serverurl")
    public String getServerurl() {
        return serverurl;
    }

    @JsonProperty("serverurl")
    public void setServerurl(String serverurl) {
        this.serverurl = serverurl;
    }

    @JsonProperty("logpath")
    public String getLogpath() {
        return logpath;
    }

    @JsonProperty("logpath")
    public void setLogpath(String logpath) {
        this.logpath = logpath;
    }

    @JsonProperty("logginglevel")
    public String getLogginglevel() {
        return logginglevel;
    }

    @JsonProperty("logginglevel")
    public void setLogginglevel(String logginglevel) {
        this.logginglevel = logginglevel;
    }

    @JsonProperty("bundleserverprops")
    public String getBundleserverprops() {
        return bundleserverprops;
    }

    @JsonProperty("bundleserverprops")
    public void setBundleserverprops(String bundleserverprops) {
        this.bundleserverprops = bundleserverprops;
    }

    @JsonProperty("genconvhtml")
    public String getGenconvhtml() {
        return genconvhtml;
    }

    @JsonProperty("genconvhtml")
    public void setGenconvhtml(String genconvhtml) {
        this.genconvhtml = genconvhtml;
    }

    @JsonProperty("metadatadsn")
    public String getMetadatadsn() {
        return metadatadsn;
    }

    @JsonProperty("metadatadsn")
    public void setMetadatadsn(String metadatadsn) {
        this.metadatadsn = metadatadsn;
    }

    @JsonProperty("admindsn")
    public String getAdmindsn() {
        return admindsn;
    }

    @JsonProperty("admindsn")
    public void setAdmindsn(String admindsn) {
        this.admindsn = admindsn;
    }

    @JsonProperty("staticanalyzer")
    public Boolean getStaticanalyzer() {
        return staticanalyzer;
    }

    @JsonProperty("staticanalyzer")
    public void setStaticanalyzer(Boolean staticanalyzer) {
        this.staticanalyzer = staticanalyzer;
    }

    @JsonProperty("enablemonitoring")
    public Boolean getEnablemonitoring() {
        return enablemonitoring;
    }

    @JsonProperty("enablemonitoring")
    public void setEnablemonitoring(Boolean enablemonitoring) {
        this.enablemonitoring = enablemonitoring;
    }

    @JsonProperty("httpkeystorepath")
    public String getHttpkeystorepath() {
        return httpkeystorepath;
    }

    @JsonProperty("httpkeystorepath")
    public void setHttpkeystorepath(String httpkeystorepath) {
        this.httpkeystorepath = httpkeystorepath;
    }

    @JsonProperty("httpkeystorepwd")
    public String getHttpkeystorepwd() {
        return httpkeystorepwd;
    }

    @JsonProperty("httpkeystorepwd")
    public void setHttpkeystorepwd(String httpkeystorepwd) {
        this.httpkeystorepwd = httpkeystorepwd;
    }

    @JsonProperty("httpkeypwd")
    public String getHttpkeypwd() {
        return httpkeypwd;
    }

    @JsonProperty("httpkeypwd")
    public void setHttpkeypwd(String httpkeypwd) {
        this.httpkeypwd = httpkeypwd;
    }

    @JsonProperty("truststorepath")
    public String getTruststorepath() {
        return truststorepath;
    }

    @JsonProperty("truststorepath")
    public void setTruststorepath(String truststorepath) {
        this.truststorepath = truststorepath;
    }

    @JsonProperty("truststorepwd")
    public String getTruststorepwd() {
        return truststorepwd;
    }

    @JsonProperty("truststorepwd")
    public void setTruststorepwd(String truststorepwd) {
        this.truststorepwd = truststorepwd;
    }

    @JsonProperty("smsport")
    public String getSmsport() {
        return smsport;
    }

    @JsonProperty("smsport")
    public void setSmsport(String smsport) {
        this.smsport = smsport;
    }

    @JsonProperty("devicedestinationport")
    public String getDevicedestinationport() {
        return devicedestinationport;
    }

    @JsonProperty("devicedestinationport")
    public void setDevicedestinationport(String devicedestinationport) {
        this.devicedestinationport = devicedestinationport;
    }

    @JsonProperty("privateKey")
    public String getPrivateKey() {
        return privateKey;
    }

    @JsonProperty("privateKey")
    public void setPrivateKey(String privateKey) {
        this.privateKey = privateKey;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
