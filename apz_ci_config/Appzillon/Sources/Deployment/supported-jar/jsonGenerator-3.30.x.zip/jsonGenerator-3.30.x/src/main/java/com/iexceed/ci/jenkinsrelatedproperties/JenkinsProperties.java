
package com.iexceed.ci.jenkinsrelatedproperties;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "BaseAppName",
    "ServerWarName",
    "ServerType",
    "AppzillonBuildPath",
    "BuildAppPath",
    "BuildServerPath",
    "ServerDebugLevel",
    "DBType",
    "BundleWebProps",
    "codecoverage",
    "DisableSessionStickyness",
    "BundleServerProps",
    "IncludeMicroApp"
    
})
public class JenkinsProperties {

    @JsonProperty("BaseAppName")
    private String baseAppName;
    @JsonProperty("ServerWarName")
    private String serverWarName;
    @JsonProperty("ServerType")
    private String serverType;
    @JsonProperty("AppzillonBuildPath")
    private String appzillonBuildPath;
    @JsonProperty("BuildAppPath")
    private String buildAppPath;
	@JsonProperty("BuildServerPath")
    private String buildServerPath;
    @JsonProperty("ServerDebugLevel")
    private String serverDebugLevel;
    @JsonProperty("DBType")
    private String dbtype;
    @JsonProperty("BundleWebProps")
    private String bundleweprops;
    @JsonProperty("DisableSessionStickyness")
    private String DisableSessionStickyness;
    @JsonProperty("codecoverage")
    private String Codecoverage;
    @JsonProperty("BundleServerProps")
    private String bundleserverprops;
    @JsonProperty("IncludeMicroApp")
    private String includeMicroApp;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("BaseAppName")
    public String getBaseAppName() {
        return baseAppName;
    }

    @JsonProperty("BaseAppName")
    public void setBaseAppName(String baseAppName) {
        this.baseAppName = baseAppName;
    }

    @JsonProperty("ServerWarName")
    public String getServerWarName() {
        return serverWarName;
    }

    @JsonProperty("ServerWarName")
    public void setServerWarName(String serverWarName) {
        this.serverWarName = serverWarName;
    }

    @JsonProperty("ServerType")
    public String getServerType() {
        return serverType;
    }

    @JsonProperty("ServerType")
    public void setServerType(String serverType) {
        this.serverType = serverType;
    }

    @JsonProperty("AppzillonBuildPath")
    public String getAppzillonBuildPath() {
        return appzillonBuildPath;
    }

    @JsonProperty("AppzillonBuildPath")
    public void setAppzillonBuildPath(String appzillonBuildPath) {
        this.appzillonBuildPath = appzillonBuildPath;
    }

    @JsonProperty("BuildAppPath")
    public String getBuildAppPath() {
        return buildAppPath;
    }

    @JsonProperty("BuildAppPath")
    public void setBuildAppPath(String buildAppPath) {
        this.buildAppPath = buildAppPath;
    }

    @JsonProperty("BuildServerPath")
    public String getBuildServerPath() {
        return buildServerPath;
    }

    @JsonProperty("BuildServerPath")
    public void setBuildServerPath(String buildServerPath) {
        this.buildServerPath = buildServerPath;
    }

    @JsonProperty("ServerDebugLevel")
    public String getServerDebugLevel() {
        return serverDebugLevel;
    }

    @JsonProperty("ServerDebugLevel")
    public void setServerDebugLevel(String serverDebugLevel) {
        this.serverDebugLevel = serverDebugLevel;
    }

    @JsonProperty("DBType")
    public String getDBType() {
        return dbtype;
    }

    @JsonProperty("DBType")
    public void setDBType(String dbtype) {
        this.dbtype = dbtype;
    }

 
    @JsonProperty("BundleWebProps")
    public String getBundleWebProps() {
        return bundleweprops;
    }

    @JsonProperty("BundleWebProps")
    public void setBundleWebProps(String bundleweprops) {
        this.bundleweprops = bundleweprops;
    }

    @JsonProperty("DisableSessionStickyness")
    public String getDisableSessionStickyness() {
        return DisableSessionStickyness;
    }
    @JsonProperty("DisableSessionStickyness")
    public void setDisableSessionStickyness(String disableSessionStickyness) {
        DisableSessionStickyness = disableSessionStickyness;
    }
    
    @JsonProperty("codecoverage")
    public String getCodecoverage() {
        return Codecoverage;
    }
    @JsonProperty("codecoverage")
    public void setCodecoverage(String codecoverage) {
    	Codecoverage = codecoverage;
    }
    
    @JsonProperty("BundleServerProps")
    public String getBundleServerProps() {
        return bundleserverprops;
    }

    @JsonProperty("BundleServerProps")
    public void setBundleServerProps(String bundleserverprops) {
        this.bundleserverprops = bundleserverprops;
    }    

    @JsonProperty("IncludeMicroApp")
    public String getIncludeMicroApp() {
		return includeMicroApp;
    }
    
    @JsonProperty("IncludeMicroApp")
	public void setIncludeMicroApp(String includeMicroApp) {
		this.includeMicroApp = includeMicroApp;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return "JenkinsProperties{" +
                "baseAppName='" + baseAppName + '\'' +
                ", serverWarName='" + serverWarName + '\'' +
                ", serverType='" + serverType + '\'' +
                ", appzillonBuildPath='" + appzillonBuildPath + '\'' +
                ", buildAppPath='" + buildAppPath + '\'' +
                ", buildServerPath='" + buildServerPath + '\'' +
                ", serverDebugLevel='" + serverDebugLevel + '\'' +
                ", dbtype='" + dbtype + '\'' +
                ", bundleweprops='" + bundleweprops + '\'' +
                ", codecoverage='" + Codecoverage + '\'' +
                ", DisableSessionStickyness='" + DisableSessionStickyness + '\'' +
                ", bundleserverprops='" + bundleserverprops + '\'' +
                ", includeMicroApp='" + includeMicroApp + '\'' +
                ", additionalProperties=" + additionalProperties +
                '}';
    }
}
