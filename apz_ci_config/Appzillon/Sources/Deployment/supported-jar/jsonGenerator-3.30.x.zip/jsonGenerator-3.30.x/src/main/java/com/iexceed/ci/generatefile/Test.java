package com.iexceed.ci.generatefile;

import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iexceed.ci.jenkinsrelatedproperties.JenkinsProperties;
import com.iexceed.ci.microappdtls.MicroAppMain;
import com.iexceed.ci.webpreference.WebPref;

public class Test {
	
	static ObjectMapper mapper = new ObjectMapper();
	public static void main(String[] args) {
		try{
		String projectFilePath = "/mnt/215f2744-2054-4758-a3af-897e69c8978b/Data/Projects/Appzillon/Appzillon-3.14.0.17092021/app/projects";
		String environment = "Env";
		String buildMode = "DEBUG";
		String includeMicroApp = "Y";
		String jenkinsProp = projectFilePath + "/Properties.json";
		JenkinsProperties objJenkinsProp = mapper.readValue(new File(jenkinsProp), JenkinsProperties.class);
		System.out.println(objJenkinsProp);
		String baseAppName = objJenkinsProp.getBaseAppName();
		String baseAppPropFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + ".apzprj";
	
		String microAppPropFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + '/'
				+ "microapps.apzmicroapps";
		
	
		String envPropFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName
				+ "/staticdata/environments/" + environment + ".apzenv";
		
		String webOsFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + "/osprefs/web.apzosprefs";
		
		
		String serverPrefFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + "/serverpreferences.apzsrvprefs";
		//String androidPrefFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + "/osprefs/android.apzosprefs";
		//System.out.println("androidPath : "+androidPrefFilePath);

		PropertiesDtls propertiesObj = new PropertiesDtls(projectFilePath, baseAppName, buildMode, objJenkinsProp,
					baseAppPropFilePath, microAppPropFilePath, envPropFilePath, webOsFilePath, serverPrefFilePath,
					"", "", "Y", "", "", "");

		if("Y".equalsIgnoreCase(objJenkinsProp.getIncludeMicroApp())) {
			propertiesObj.getObjMicroApp().setMicroappsfolder(propertiesObj.getProjectFilePath()+"/MicroApp");
			MicroAppMain objMicroApp = mapper.readValue(new File(microAppPropFilePath), MicroAppMain.class);
			System.out.println("Before change : "+objMicroApp);

			mapper.writeValue(new File(microAppPropFilePath),propertiesObj.getObjMicroApp());
			MicroAppMain objMicroApp1 = mapper.readValue(new File(microAppPropFilePath), MicroAppMain.class);
			System.out.println("After change : "+objMicroApp1);
		}

		/*WebPref webPrefDummy = new WebPref();
		webPrefDummy = null;
		if(webPrefDummy != null){
			System.out.println("I am not null");
		}else{
			System.out.println("I am  null");
			System.out.println("I am not null :"+webPrefDummy.toString());
		}*/
	
	}catch(Exception e){
		e.printStackTrace();
	}
	}
}
