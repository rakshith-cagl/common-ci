
package com.iexceed.ci.webpreference;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "typeclass",
    "name",
    "type",
    "childs",
    "weblogdir",
    "webusersettingspath",
    "websessiontimeout",
    "safekey",
    "buildmode",
    "httponlycookie",
    "securecookie",
    "csrfprevention",
    "overrideotp"
})
public class WebPref_bckup {

    @Override
	public String toString() {
		return "WebPref [typeclass=" + typeclass + ", name=" + name + ", type=" + type + ", childs=" + childs
				+ ", weblogdir=" + weblogdir + ", webusersettingspath=" + webusersettingspath + ", websessiontimeout="
				+ websessiontimeout + ", safekey=" + safekey + ", buildmode=" + buildmode + ", httponlycookie="
				+ httponlycookie + ", securecookie=" + securecookie + ", csrfprevention=" + csrfprevention
				+ ", overrideotp=" + overrideotp + ", additionalProperties=" + additionalProperties + "]";
	}

	@JsonProperty("typeclass")
    private String typeclass;
    @JsonProperty("name")
    private String name;
    @JsonProperty("type")
    private String type;
    @JsonProperty("childs")
    private List<Object> childs = null;
    @JsonProperty("weblogdir")
    private String weblogdir;
    @JsonProperty("webusersettingspath")
    private String webusersettingspath;
    @JsonProperty("websessiontimeout")
    private String websessiontimeout;
    @JsonProperty("safekey")
    private String safekey;
    @JsonProperty("buildmode")
    private String buildmode;
    @JsonProperty("httponlycookie")
    private String httponlycookie;
    @JsonProperty("securecookie")
    private String securecookie;
    @JsonProperty("csrfprevention")
    private String csrfprevention;
    @JsonProperty("overrideotp")
    private String overrideotp;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("typeclass")
    public String getTypeclass() {
        return typeclass;
    }

    @JsonProperty("typeclass")
    public void setTypeclass(String typeclass) {
        this.typeclass = typeclass;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("childs")
    public List<Object> getChilds() {
        return childs;
    }

    @JsonProperty("childs")
    public void setChilds(List<Object> childs) {
        this.childs = childs;
    }

    @JsonProperty("weblogdir")
    public String getWeblogdir() {
        return weblogdir;
    }

    @JsonProperty("weblogdir")
    public void setWeblogdir(String weblogdir) {
        this.weblogdir = weblogdir;
    }

    @JsonProperty("webusersettingspath")
    public String getWebusersettingspath() {
        return webusersettingspath;
    }

    @JsonProperty("webusersettingspath")
    public void setWebusersettingspath(String webusersettingspath) {
        this.webusersettingspath = webusersettingspath;
    }

    @JsonProperty("websessiontimeout")
    public String getWebsessiontimeout() {
        return websessiontimeout;
    }

    @JsonProperty("websessiontimeout")
    public void setWebsessiontimeout(String websessiontimeout) {
        this.websessiontimeout = websessiontimeout;
    }

    @JsonProperty("safekey")
    public String getSafekey() {
        return safekey;
    }

    @JsonProperty("safekey")
    public void setSafekey(String safekey) {
        this.safekey = safekey;
    }

    @JsonProperty("buildmode")
    public String getBuildmode() {
        return buildmode;
    }

    @JsonProperty("buildmode")
    public void setBuildmode(String buildmode) {
        this.buildmode = buildmode;
    }

    @JsonProperty("httponlycookie")
    public String getHttponlycookie() {
        return httponlycookie;
    }

    @JsonProperty("httponlycookie")
    public void setHttponlycookie(String httponlycookie) {
        this.httponlycookie = httponlycookie;
    }

    @JsonProperty("securecookie")
    public String getSecurecookie() {
        return securecookie;
    }

    @JsonProperty("securecookie")
    public void setSecurecookie(String securecookie) {
        this.securecookie = securecookie;
    }

    @JsonProperty("csrfprevention")
    public String getCsrfprevention() {
        return csrfprevention;
    }

    @JsonProperty("csrfprevention")
    public void setCsrfprevention(String csrfprevention) {
        this.csrfprevention = csrfprevention;
    }

    @JsonProperty("overrideotp")
    public String getOverrideotp() {
        return overrideotp;
    }

    @JsonProperty("overrideotp")
    public void setOverrideotp(String overrideotp) {
        this.overrideotp = overrideotp;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
