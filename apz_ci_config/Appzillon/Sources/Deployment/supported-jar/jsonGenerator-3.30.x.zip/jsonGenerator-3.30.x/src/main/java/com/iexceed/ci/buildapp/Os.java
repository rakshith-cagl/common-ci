
package com.iexceed.ci.buildapp;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "name", "typeclass", "state", "status", "buildmode", "warfilename", "logdir", "settingspath",
		"httpkeystorepath", "keystorepassword", "truststorepath", "bundlewebprops", "httponlycookie", "securecookie",
		"csrfprevention", "safekey", "truststorepwd", "keystorepath", "keystorepwd", "keystorealias",
		"keystorealiaspwd", "obfuscation" })
public class Os {

	@JsonProperty("name")
	private String name;
	@JsonProperty("typeclass")
	private String typeclass;
	@JsonProperty("state")
	private String state;
	@JsonProperty("status")
	private String status;
	@JsonProperty("buildmode")
	private String buildmode;
	@JsonProperty("warfilename")
	private String warfilename;
	@JsonProperty("logdir")
	private String logdir;
	@JsonProperty("settingspath")
	private String settingspath;
	@JsonProperty("httpkeystorepath")
	private String httpkeystorepath;
	@JsonProperty("keystorepassword")
	private String keystorepassword;
	@JsonProperty("truststorepath")
	private String truststorepath;
	@JsonProperty("bundlewebprops")
	private String bundlewebprops;
	@JsonProperty("httponlycookie")
	private String httponlycookie;
	@JsonProperty("securecookie")
	private String securecookie;
	@JsonProperty("csrfprevention")
	private String csrfprevention;
	@JsonProperty("safekey")
	private String safekey;
	@JsonProperty("truststorepwd")
	private String truststorepwd;
	@JsonProperty("keystorepath")
	private String keystorepath;
	@JsonProperty("keystorepwd")
	private String keystorepwd;
	@JsonProperty("keystorealias")
	private String keystorealias;
	@JsonProperty("keystorealiaspwd")
	private String keystorealiaspwd;
	@JsonProperty("obfuscation")
	private String obfuscation;
	/* 3.7.5- additional properties */
	@JsonProperty("keepsignedin")
	private String keepsignedin;
	@JsonProperty("cookieage")
	private String cookieage;
	@JsonProperty("buildinstaller")
	private String buildinstaller;
	@JsonProperty("buildtypeuniversal")
	private String buildtypeuniversal;
	@JsonProperty("buildtype32bitarm")
	private String buildtype32bitarm;
	@JsonProperty("buildtype32bitx86")
	private String buildtype32bitx86;
	@JsonProperty("buildtype64bitarm")
	private String buildtype64bitarm;
	@JsonProperty("buildtype64bitx86")
	private String buildtype64bitx86;
	@JsonProperty("buildtypehuawei")
	private String buildtypehuawei;
	@JsonProperty("buildsdktype")
	private String buildsdktype;
	@JsonProperty("gdapplicationid")
	private String gdapplicationid;
	@JsonProperty("gdapplicationversion")
	private String gdapplicationversion;
	@JsonProperty("iosbuildtype")
	private String iosbuildtype;
	@JsonProperty("storecertpath")
	private String storecertpath;
	/* 3.10 disable session stickyness */
	@JsonProperty("sessionstickyness")
	private String sessionstickyness;
	@JsonProperty("codecoverage")
	private String codecoverage;
	@JsonProperty("ppuuid")
	private String ppuuid;
	@JsonProperty("ppname")
	private String ppname;
	@JsonProperty("developmentteam")
	private String developmentteam;
	@JsonProperty("deployementmode")
	private String deployementmode;

	@JsonProperty("keepsignedin")
	public String getKeepsignedin() {
		return keepsignedin;
	}

	@JsonProperty("keepsignedin")
	public void setKeepsignedin(String keepsignedin) {
		this.keepsignedin = keepsignedin;
	}

	@JsonProperty("cookieage")
	public String getCookieage() {
		return cookieage;
	}

	@JsonProperty("cookieage")
	public void setCookieage(String cookieage) {
		this.cookieage = cookieage;
	}

	@JsonProperty("buildinstaller")
	public String getBuildinstaller() {
		return buildinstaller;
	}

	@JsonProperty("buildinstaller")
	public void setBuildinstaller(String buildinstaller) {
		this.buildinstaller = buildinstaller;
	}

	@JsonProperty("buildtypeuniversal")
	public String getBuildtypeuniversal() {
		return buildtypeuniversal;
	}

	@JsonProperty("buildtypeuniversal")
	public void setBuildtypeuniversal(String buildtypeuniversal) {
		this.buildtypeuniversal = buildtypeuniversal;
	}

	@JsonProperty("buildtype32bitarm")
	public String getBuildtype32bitarm() {
		return buildtype32bitarm;
	}

	@JsonProperty("buildtype32bitarm")
	public void setBuildtype32bitarm(String buildtype32bitarm) {
		this.buildtype32bitarm = buildtype32bitarm;
	}

	@JsonProperty("buildtype32bitx86")
	public String getBuildtype32bitx86() {
		return buildtype32bitx86;
	}

	@JsonProperty("buildtype32bitx86")
	public void setBuildtype32bitx86(String buildtype32bitx86) {
		this.buildtype32bitx86 = buildtype32bitx86;
	}

	@JsonProperty("buildtype64bitarm")
	public String getBuildtype64bitarm() {
		return buildtype64bitarm;
	}

	@JsonProperty("buildtype64bitarm")
	public void setBuildtype64bitarm(String buildtype64bitarm) {
		this.buildtype64bitarm = buildtype64bitarm;
	}

	@JsonProperty("buildtype64bitx86")
	public String getBuildtype64bitx86() {
		return buildtype64bitx86;
	}

	@JsonProperty("buildtype64bitx86")
	public void setBuildtype64bitx86(String buildtype64bitx86) {
		this.buildtype64bitx86 = buildtype64bitx86;
	}
	
	@JsonProperty("buildtypehuawei")
	public String getBuildtypehuawei() {
		return buildtypehuawei;
	}

	@JsonProperty("buildtypehuawei")
	public void setBuildtypehuawei(String buildtypehuawei) {
		this.buildtypehuawei = buildtypehuawei;
	}
	
	@JsonProperty("buildsdktype")
	public String getBuildsdktype() {
		return buildsdktype;
	}

	@JsonProperty("buildsdktype")
	public void setBuildsdktype(String buildsdktype) {
		this.buildsdktype = buildsdktype;
	}

	@JsonProperty("gdapplicationid")
	public String getGdapplicationid() {
		return gdapplicationid;
	}

	@JsonProperty("gdapplicationid")
	public void setGdapplicationid(String gdapplicationid) {
		this.gdapplicationid = gdapplicationid;
	}

	@JsonProperty("gdapplicationversion")
	public String getGdapplicationversion() {
		return gdapplicationversion;
	}

	@JsonProperty("gdapplicationversion")
	public void setGdapplicationversion(String gdapplicationversion) {
		this.gdapplicationversion = gdapplicationversion;
	}

	@JsonProperty("iosbuildtype")
	public String getIosbuildtype() {
		return iosbuildtype;
	}

	@JsonProperty("iosbuildtype")
	public void setIosbuildtype(String iosbuildtype) {
		this.iosbuildtype = iosbuildtype;
	}

	@JsonProperty("storecertpath")
	public String getStorecertpath() {
		return storecertpath;
	}

	@JsonProperty("storecertpath")
	public void setStorecertpath(String storecertpath) {
		this.storecertpath = storecertpath;
	}

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("typeclass")
	public String getTypeclass() {
		return typeclass;
	}

	@JsonProperty("typeclass")
	public void setTypeclass(String typeclass) {
		this.typeclass = typeclass;
	}

	@JsonProperty("state")
	public String getState() {
		return state;
	}

	@JsonProperty("state")
	public void setState(String state) {
		this.state = state;
	}

	@JsonProperty("status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("buildmode")
	public String getBuildmode() {
		return buildmode;
	}

	@JsonProperty("buildmode")
	public void setBuildmode(String buildmode) {
		this.buildmode = buildmode;
	}

	@JsonProperty("warfilename")
	public String getWarfilename() {
		return warfilename;
	}

	@JsonProperty("warfilename")
	public void setWarfilename(String warfilename) {
		this.warfilename = warfilename;
	}

	@JsonProperty("logdir")
	public String getLogdir() {
		return logdir;
	}

	@JsonProperty("logdir")
	public void setLogdir(String logdir) {
		this.logdir = logdir;
	}

	@JsonProperty("settingspath")
	public String getSettingspath() {
		return settingspath;
	}

	@JsonProperty("settingspath")
	public void setSettingspath(String settingspath) {
		this.settingspath = settingspath;
	}

	@JsonProperty("httpkeystorepath")
	public String getHttpkeystorepath() {
		return httpkeystorepath;
	}

	@JsonProperty("httpkeystorepath")
	public void setHttpkeystorepath(String httpkeystorepath) {
		this.httpkeystorepath = httpkeystorepath;
	}

	@JsonProperty("keystorepassword")
	public String getKeystorepassword() {
		return keystorepassword;
	}

	@JsonProperty("keystorepassword")
	public void setKeystorepassword(String keystorepassword) {
		this.keystorepassword = keystorepassword;
	}

	@JsonProperty("truststorepath")
	public String getTruststorepath() {
		return truststorepath;
	}

	@JsonProperty("truststorepath")
	public void setTruststorepath(String truststorepath) {
		this.truststorepath = truststorepath;
	}

	@JsonProperty("bundlewebprops")
	public String getBundlewebprops() {
		return bundlewebprops;
	}

	@JsonProperty("bundlewebprops")
	public void setBundlewebprops(String bundlewebprops) {
		this.bundlewebprops = bundlewebprops;
	}

	@JsonProperty("httponlycookie")
	public String getHttponlycookie() {
		return httponlycookie;
	}

	@JsonProperty("httponlycookie")
	public void setHttponlycookie(String httponlycookie) {
		this.httponlycookie = httponlycookie;
	}

	@JsonProperty("securecookie")
	public String getSecurecookie() {
		return securecookie;
	}

	@JsonProperty("securecookie")
	public void setSecurecookie(String securecookie) {
		this.securecookie = securecookie;
	}

	@JsonProperty("csrfprevention")
	public String getCsrfprevention() {
		return csrfprevention;
	}

	@JsonProperty("csrfprevention")
	public void setCsrfprevention(String csrfprevention) {
		this.csrfprevention = csrfprevention;
	}

	@JsonProperty("safekey")
	public String getSafekey() {
		return safekey;
	}

	@JsonProperty("safekey")
	public void setSafekey(String safekey) {
		this.safekey = safekey;
	}

	@JsonProperty("truststorepwd")
	public String getTruststorepwd() {
		return truststorepwd;
	}

	@JsonProperty("truststorepwd")
	public void setTruststorepwd(String truststorepwd) {
		this.truststorepwd = truststorepwd;
	}

	@JsonProperty("keystorepath")
	public String getKeystorepath() {
		return keystorepath;
	}

	@JsonProperty("keystorepath")
	public void setKeystorepath(String keystorepath) {
		this.keystorepath = keystorepath;
	}

	@JsonProperty("keystorepwd")
	public String getKeystorepwd() {
		return keystorepwd;
	}

	@JsonProperty("keystorepwd")
	public void setKeystorepwd(String keystorepwd) {
		this.keystorepwd = keystorepwd;
	}

	@JsonProperty("keystorealias")
	public String getKeystorealias() {
		return keystorealias;
	}

	@JsonProperty("keystorealias")
	public void setKeystorealias(String keystorealias) {
		this.keystorealias = keystorealias;
	}

	@JsonProperty("keystorealiaspwd")
	public String getKeystorealiaspwd() {
		return keystorealiaspwd;
	}

	@JsonProperty("keystorealiaspwd")
	public void setKeystorealiaspwd(String keystorealiaspwd) {
		this.keystorealiaspwd = keystorealiaspwd;
	}

	@JsonProperty("obfuscation")
	public String getObfuscation() {
		return obfuscation;
	}

	@JsonProperty("obfuscation")
	public void setObfuscation(String obfuscation) {
		this.obfuscation = obfuscation;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@JsonProperty("sessionstickyness")
	public String getSessionstickyness() {
		return sessionstickyness;
	}

	@JsonProperty("sessionstickyness")
	public void setSessionstickyness(String sessionstickyness) {
		this.sessionstickyness = sessionstickyness;
	}
	
	@JsonProperty("codecoverage")
	public String getCodecoverage() {
		return codecoverage;
	}

	@JsonProperty("codecoverage")
	public void setCodecoverage(String codecoverage) {
		this.codecoverage = codecoverage;
	}
	
	 @JsonProperty("ppuuid")
	    public String getppuuid() {
	        return ppuuid;
	    }

	    @JsonProperty("ppuuid")
	    public void setppuuid(String ppuuid) {
	        this.ppuuid = ppuuid;
	    }
	    
	    @JsonProperty("ppname")
	    public String getppname() {
	        return ppname;
	    }

	    @JsonProperty("ppname")
	    public void setppname(String ppname) {
	        this.ppname = ppname;
	    }
	    
	    @JsonProperty("developmentteam")
	    public String getDevelopmentteam() {
	        return developmentteam;
	    }

	    @JsonProperty("developmentteam")
	    public void setDevelopmentteam(String developmentteam) {
	        this.developmentteam = developmentteam;
	    }
	    
	    @JsonProperty("deployementmode")
	    public String getDeployementmode() {
	        return deployementmode;
	    }

	    @JsonProperty("deployementmode")
	    public void setDeployementmode(String deployementmode) {
	        this.deployementmode = deployementmode;
	    }
}
