package com.iexceed.ci.languages;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "name",
    "desc",
    "textdirection"
})
public class Languagesvariablefile {
	 @JsonProperty("name")
	    private String name;
	    @JsonProperty("desc")
	    private String desc;
	    @JsonProperty("textdirection")
	    private String textdirection;
	    @JsonIgnore
	    private Map<String, Object> languages = new HashMap<String, Object>();

	    @JsonProperty("name")
	    public String getname() {
	        return name;
	    }

	    @JsonProperty("name")
	    public void setname(String name) {
	        this.name = name;
	    }

	    @JsonProperty("desc")
	    public String getdesc() {
	        return desc;
	    }

	    @JsonProperty("desc")
	    public void setdesc(String desc) {
	        this.desc = desc;
	    }
	    
	    @JsonProperty("textdirection")
	    public String gettextdirection() {
	        return textdirection;
	    }

	    @JsonProperty("textdirection")
	    public void settextdirection(String textdirection) {
	        this.textdirection = textdirection;
	    }

	    @JsonAnyGetter
	    public Map<String, Object> getLanguage() {
	        return this.languages;
	    }

	    @JsonAnySetter
	    public void setLanguages(String name, Object value) {
	        this.languages.put(name, value);
	    }
}
