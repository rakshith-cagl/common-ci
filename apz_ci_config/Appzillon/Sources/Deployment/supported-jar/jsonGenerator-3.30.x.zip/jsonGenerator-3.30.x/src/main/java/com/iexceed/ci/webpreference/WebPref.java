
package com.iexceed.ci.webpreference;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "typeclass",
    "name",
    "type",
    "childs",
    "weblogdir",
    "webusersettingspath",
    "websessiontimeout",
    "webgoogleplusid",
    "webgooglepluskey",
    "processorbean",
    "keystorepath",
    "keystorepassword",
    "truststorepath",
    "truststorepwd",
    "safekey",
    "buildmode",
    "httponlycookie",
    "securecookie",
    "csrfprevention",
    "overrideotp",
    "keepsignedin",
    "cookieage",
    "codecoverage",
    "sessionstickyness"
})
public class WebPref {

    @Override
    public String toString() {
        return "WebPref{" +
                "typeclass='" + typeclass + '\'' +
                ", name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", childs=" + childs +
                ", weblogdir='" + weblogdir + '\'' +
                ", webusersettingspath='" + webusersettingspath + '\'' +
                ", websessiontimeout='" + websessiontimeout + '\'' +
                ", webgoogleplusid='" + webgoogleplusid + '\'' +
                ", webgooglepluskey='" + webgooglepluskey + '\'' +
                ", processorbean='" + processorbean + '\'' +
                ", keystorepath='" + keystorepath + '\'' +
                ", keystorepassword='" + keystorepassword + '\'' +
                ", truststorepath='" + truststorepath + '\'' +
                ", truststorepwd='" + truststorepwd + '\'' +
                ", safekey='" + safekey + '\'' +
                ", buildmode='" + buildmode + '\'' +
                ", httponlycookie='" + httponlycookie + '\'' +
                ", securecookie='" + securecookie + '\'' +
                ", csrfprevention='" + csrfprevention + '\'' +
                ", overrideotp='" + overrideotp + '\'' +
                ", keepsignedin='" + keepsignedin + '\'' +
                ", cookieage='" + cookieage + '\'' +
                ", codecoverage='" + Codecoverage + '\'' +
                ", sessionstickyness='" + sessionstickyness + '\'' +
                ", additionalProperties=" + additionalProperties +
                '}';
    }

    @JsonProperty("typeclass")
    private String typeclass;
    @JsonProperty("name")
    private String name;
    @JsonProperty("type")
    private String type;
    @JsonProperty("childs")
    private List<Object> childs = null;
    @JsonProperty("weblogdir")
    private String weblogdir;
    @JsonProperty("webusersettingspath")
    private String webusersettingspath;
    @JsonProperty("websessiontimeout")
    private String websessiontimeout;
    @JsonProperty("webgoogleplusid")
    private String webgoogleplusid = "";
    @JsonProperty("webgooglepluskey")
    private String webgooglepluskey = "";
    @JsonProperty("processorbean")
    private String processorbean = "";
    @JsonProperty("keystorepath")
    private String keystorepath = "";
    @JsonProperty("keystorepassword")
    private String keystorepassword = "";
    @JsonProperty("truststorepath")
    private String truststorepath = "";
    @JsonProperty("truststorepwd")
    private String truststorepwd = "";
    @JsonProperty("safekey")
    private String safekey;
    @JsonProperty("buildmode")
    private String buildmode;
    @JsonProperty("httponlycookie")
    private String httponlycookie;
    @JsonProperty("securecookie")
    private String securecookie;
    @JsonProperty("csrfprevention")
    private String csrfprevention;
    @JsonProperty("overrideotp")
    private String overrideotp;
    @JsonProperty("keepsignedin")
    private String keepsignedin;
    @JsonProperty("cookieage")
    private String cookieage;
    @JsonProperty("sessionstickyness")
    private String sessionstickyness;
    @JsonProperty("codecoverage")
    private String Codecoverage;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("typeclass")
    public String getTypeclass() {
        return typeclass;
    }

    @JsonProperty("typeclass")
    public void setTypeclass(String typeclass) {
        this.typeclass = typeclass;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("childs")
    public List<Object> getChilds() {
        return childs;
    }

    @JsonProperty("childs")
    public void setChilds(List<Object> childs) {
        this.childs = childs;
    }

    @JsonProperty("weblogdir")
    public String getWeblogdir() {
        return weblogdir;
    }

    @JsonProperty("weblogdir")
    public void setWeblogdir(String weblogdir) {
        this.weblogdir = weblogdir;
    }

    @JsonProperty("webusersettingspath")
    public String getWebusersettingspath() {
        return webusersettingspath;
    }

    @JsonProperty("webusersettingspath")
    public void setWebusersettingspath(String webusersettingspath) {
        this.webusersettingspath = webusersettingspath;
    }

    @JsonProperty("websessiontimeout")
    public String getWebsessiontimeout() {
        return websessiontimeout;
    }

    @JsonProperty("websessiontimeout")
    public void setWebsessiontimeout(String websessiontimeout) {
        this.websessiontimeout = websessiontimeout;
    }

    @JsonProperty("webgoogleplusid")
    public String getWebgoogleplusid() {
        return webgoogleplusid;
    }

    @JsonProperty("webgoogleplusid")
    public void setWebgoogleplusid(String webgoogleplusid) {
        this.webgoogleplusid = webgoogleplusid;
    }

    @JsonProperty("webgooglepluskey")
    public String getWebgooglepluskey() {
        return webgooglepluskey;
    }

    @JsonProperty("webgooglepluskey")
    public void setWebgooglepluskey(String webgooglepluskey) {
        this.webgooglepluskey = webgooglepluskey;
    }

    @JsonProperty("processorbean")
    public String getProcessorbean() {
        return processorbean;
    }

    @JsonProperty("processorbean")
    public void setProcessorbean(String processorbean) {
        this.processorbean = processorbean;
    }

    @JsonProperty("keystorepath")
    public String getKeystorepath() {
        return keystorepath;
    }

    @JsonProperty("keystorepath")
    public void setKeystorepath(String keystorepath) {
        this.keystorepath = keystorepath;
    }

    @JsonProperty("keystorepassword")
    public String getKeystorepassword() {
        return keystorepassword;
    }

    @JsonProperty("keystorepassword")
    public void setKeystorepassword(String keystorepassword) {
        this.keystorepassword = keystorepassword;
    }

    @JsonProperty("truststorepath")
    public String getTruststorepath() {
        return truststorepath;
    }

    @JsonProperty("truststorepath")
    public void setTruststorepath(String truststorepath) {
        this.truststorepath = truststorepath;
    }

    @JsonProperty("truststorepwd")
    public String getTruststorepwd() {
        return truststorepwd;
    }

    @JsonProperty("truststorepwd")
    public void setTruststorepwd(String truststorepwd) {
        this.truststorepwd = truststorepwd;
    }

    @JsonProperty("safekey")
    public String getSafekey() {
        return safekey;
    }

    @JsonProperty("safekey")
    public void setSafekey(String safekey) {
        this.safekey = safekey;
    }

    @JsonProperty("buildmode")
    public String getBuildmode() {
        return buildmode;
    }

    @JsonProperty("buildmode")
    public void setBuildmode(String buildmode) {
        this.buildmode = buildmode;
    }

    @JsonProperty("httponlycookie")
    public String getHttponlycookie() {
        return httponlycookie;
    }

    @JsonProperty("httponlycookie")
    public void setHttponlycookie(String httponlycookie) {
        this.httponlycookie = httponlycookie;
    }

    @JsonProperty("securecookie")
    public String getSecurecookie() {
        return securecookie;
    }

    @JsonProperty("securecookie")
    public void setSecurecookie(String securecookie) {
        this.securecookie = securecookie;
    }

    @JsonProperty("csrfprevention")
    public String getCsrfprevention() {
        return csrfprevention;
    }

    @JsonProperty("csrfprevention")
    public void setCsrfprevention(String csrfprevention) {
        this.csrfprevention = csrfprevention;
    }

    @JsonProperty("overrideotp")
    public String getOverrideotp() {
        return overrideotp;
    }

    @JsonProperty("overrideotp")
    public void setOverrideotp(String overrideotp) {
        this.overrideotp = overrideotp;
    }

    @JsonProperty("keepsignedin")
    public String getKeepsignedin() {
        return keepsignedin;
    }

    @JsonProperty("keepsignedin")
    public void setKeepsignedin(String keepsignedin) {
        this.keepsignedin = keepsignedin;
    }

    @JsonProperty("cookieage")
    public String getCookieage() {
        return cookieage;
    }

    @JsonProperty("cookieage")
    public void setCookieage(String cookieage) {
        this.cookieage = cookieage;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @JsonProperty("sessionstickyness")
    public String getSessionstickyness() {
        return sessionstickyness;
    }
    @JsonProperty("sessionstickyness")
    public void setSessionstickyness(String sessionstickyness) {
        this.sessionstickyness = sessionstickyness;
    }
    
    @JsonProperty("codecoverage")
    public String getCodecoverage() {
        return Codecoverage;
    }
    @JsonProperty("codecoverage")
    public void setCodecoverage(String codecoverage) {
        this.Codecoverage = codecoverage;
    }
}
