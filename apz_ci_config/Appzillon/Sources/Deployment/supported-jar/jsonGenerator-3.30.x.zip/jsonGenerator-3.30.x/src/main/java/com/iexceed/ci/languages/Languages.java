package com.iexceed.ci.languages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.iexceed.ci.environment.Environmentvariablefile;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "typeclass",
    "name",
    "type",
    "languages"
})
public class Languages {
	
	 @Override
		public String toString() {
			return "[" + languages + "]";
		}
	 
	@JsonProperty("typeclass")
    private String typeclass;
    @JsonProperty("name")
    private String name;
    @JsonProperty("type")
    private String type;
    @JsonProperty("languagevariablefile")
    private List<Languagesvariablefile> languagevariablefile = null;
    @JsonIgnore
    private Map<String, Object> languages = new HashMap<String, Object>();
    
    @JsonProperty("typeclass")
    public String getTypeclass() {
        return typeclass;
    }

    @JsonProperty("typeclass")
    public void setTypeclass(String typeclass) {
        this.typeclass = typeclass;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }
    
    @JsonProperty("languagevariablefile")
    public List<Languagesvariablefile> getLanguagesvariablefile() {
        return languagevariablefile;
    }

    @JsonProperty("languagevariablefile")
    public void setLanguagesvariablefile(List<Languagesvariablefile> languagevariablefile) {
        this.languagevariablefile = languagevariablefile;
    }

    @JsonAnyGetter
    public Map<String, Object> getLanguage() {
        return this.languages;
    }

    @JsonAnySetter
    public void setLanguages(String name, Object value) {
        this.languages.put(name, value);
    }
}
