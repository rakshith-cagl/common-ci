
package com.iexceed.ci.serverpreference;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "typeclass",
    "name",
    "type",
    "childs",
    "keystorepath",
    "keystorepwd",
    "keypassword",
    "truststorepath",
    "truststorepwd",
    "transactionlogging",
    "logpayload",
    "owaspsanitizerrequired",
    "mysqlcodecrequired",
    "oraclecodecrequired",
    "percentcodecrequired",
    "pushbackstringrequired",
    "htmlentitycodecrequired",
    "xmlentitycodecrequired",
    "javascriptcodecrequired",
    "defaultauthorization",
    "servertoken",
    "mailfrom",
    "portnumber",
    "hostname",
    "sessiontimeout",
    "servicetimeout",
    "logpath",
    "protocol",
    "username",
    "jasperfilepath",
    "metadatadsn",
    "admindsn",
    "devicedestinationport",
    "smsport",
    "serversmsnumber",
    "textmessagingserviceclass",
    "otplength",
    "otpvalidcount",
    "otpexpiry",
    "otpformat",
    "otpresend",
    "otpresendcount",
    "otpresendlocktime",
    "multitenancy",
    "typeoflogging",
    "rolloverlog",
    "logfilemaxsize",
    "defrolloverstrategy",
    "kafkaservers",
    "maxramalloc",
    "recordbatchsize",
    "smsbeanslist",
    "notifbeanslist",
    "translationimplementationclass",
    "publickey",
    "privatekey"
})
public class ServerPreference {

    @JsonProperty("typeclass")
    private String typeclass;
    @JsonProperty("name")
    private String name;
    @JsonProperty("type")
    private String type;
    @JsonProperty("childs")
    private List<Object> childs = null;
    @JsonProperty("keystorepath")
    private String keystorepath = "";
    @JsonProperty("keystorepwd")
    private String keystorepwd = "";
    @JsonProperty("keypassword")
    private String keypassword = "";
    @JsonProperty("truststorepath")
    private String truststorepath = "";
    @JsonProperty("truststorepwd")
    private String truststorepwd = "";
    @JsonProperty("transactionlogging")
    private String transactionlogging;
    @JsonProperty("logpayload")
    private String logpayload;
    @JsonProperty("owaspsanitizerrequired")
    private String owaspsanitizerrequired;
    @JsonProperty("mysqlcodecrequired")
    private String mysqlcodecrequired;
    @JsonProperty("oraclecodecrequired")
    private String oraclecodecrequired;
    @JsonProperty("percentcodecrequired")
    private String percentcodecrequired;
    @JsonProperty("pushbackstringrequired")
    private String pushbackstringrequired;
    @JsonProperty("htmlentitycodecrequired")
    private String htmlentitycodecrequired;
    @JsonProperty("xmlentitycodecrequired")
    private String xmlentitycodecrequired;
    @JsonProperty("javascriptcodecrequired")
    private String javascriptcodecrequired;
    @JsonProperty("defaultauthorization")
    private String defaultauthorization;
    @JsonProperty("servertoken")
    private String servertoken;
    @JsonProperty("mailfrom")
    private String mailfrom;
    @JsonProperty("portnumber")
    private String portnumber;
    @JsonProperty("hostname")
    private String hostname;
    @JsonProperty("sessiontimeout")
    private String sessiontimeout;
    @JsonProperty("servicetimeout")
    private String servicetimeout;
    @JsonProperty("logpath")
    private String logpath;
    @JsonProperty("protocol")
    private String protocol;
    @JsonProperty("username")
    private String username;
    @JsonProperty("jasperfilepath")
    private String jasperfilepath;
    @JsonProperty("metadatadsn")
    private String metadatadsn;
    @JsonProperty("admindsn")
    private String admindsn;
    @JsonProperty("devicedestinationport")
    private String devicedestinationport;
    @JsonProperty("smsport")
    private String smsport;
    @JsonProperty("serversmsnumber")
    private String serversmsnumber;
    @JsonProperty("textmessagingserviceclass")
    private String textmessagingserviceclass;
    @JsonProperty("otplength")
    private String otplength;
    @JsonProperty("otpvalidcount")
    private String otpvalidcount;
    @JsonProperty("otpexpiry")
    private String otpexpiry;
    @JsonProperty("otpformat")
    private String otpformat;
    @JsonProperty("otpresend")
    private String otpresend;
    @JsonProperty("otpresendcount")
    private String otpresendcount;
    @JsonProperty("otpresendlocktime")
    private String otpresendlocktime;
    @JsonProperty("multitenancy")
    private String multitenancy;
    @JsonProperty("typeoflogging")
    private String typeoflogging;
    @JsonProperty("rolloverlog")
    private String rolloverlog;
    @JsonProperty("logfilemaxsize")
    private String logfilemaxsize;
    @JsonProperty("defrolloverstrategy")
    private String defrolloverstrategy;
    @JsonProperty("kafkaservers")
    private String kafkaservers;
    @JsonProperty("maxramalloc")
    private String maxramalloc;
    @JsonProperty("recordbatchsize")
    private String recordbatchsize;
    @JsonProperty("smsbeanslist")
    private List<Smsbeanslist> smsbeanslist = null;
    @JsonProperty("notifbeanslist")
    private List<Notifbeanslist> notifbeanslist = null;
    @JsonProperty("translationimplementationclass")
    private String translationimplementationclass;
    @JsonProperty("publickey")
    private String publickey;
    @JsonProperty("privatekey")
    private String privatekey;
    @Override
	public String toString() {
		return "ServerPreference [typeclass=" + typeclass + ", name=" + name + ", type=" + type + ", childs=" + childs
				+ ", keystorepath=" + keystorepath + ", keystorepwd=" + keystorepwd + ", keypassword=" + keypassword
				+ ", truststorepath=" + truststorepath + ", truststorepwd=" + truststorepwd + ", transactionlogging="
				+ transactionlogging + ", logpayload=" + logpayload + ", owaspsanitizerrequired="
				+ owaspsanitizerrequired + ", mysqlcodecrequired=" + mysqlcodecrequired + ", oraclecodecrequired="
				+ oraclecodecrequired + ", percentcodecrequired=" + percentcodecrequired + ", pushbackstringrequired="
				+ pushbackstringrequired + ", htmlentitycodecrequired=" + htmlentitycodecrequired
				+ ", xmlentitycodecrequired=" + xmlentitycodecrequired + ", javascriptcodecrequired="
				+ javascriptcodecrequired + ", defaultauthorization=" + defaultauthorization + ", servertoken="
				+ servertoken + ", mailfrom=" + mailfrom + ", portnumber=" + portnumber + ", hostname=" + hostname
				+ ", sessiontimeout=" + sessiontimeout + ", servicetimeout=" + servicetimeout + ", logpath=" + logpath
				+ ", protocol=" + protocol + ", username=" + username + ", jasperfilepath=" + jasperfilepath
				+ ", metadatadsn=" + metadatadsn + ", admindsn=" + admindsn + ", devicedestinationport="
				+ devicedestinationport + ", smsport=" + smsport + ", serversmsnumber=" + serversmsnumber
				+ ", textmessagingserviceclass=" + textmessagingserviceclass + ", otplength=" + otplength
				+ ", otpvalidcount=" + otpvalidcount + ", otpexpiry=" + otpexpiry + ", otpformat=" + otpformat
				+ ", otpresend=" + otpresend + ", otpresendcount=" + otpresendcount + ", otpresendlocktime="
				+ otpresendlocktime + ", smsbeanslist=" + smsbeanslist + ", notifbeanslist=" + notifbeanslist
				+ ", translationimplementationclass=" + translationimplementationclass + ", publickey=" + publickey
				+ ", privatekey=" + privatekey + ", additionalProperties=" + additionalProperties + "]";
	}

	@JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("typeclass")
    public String getTypeclass() {
        return typeclass;
    }

    @JsonProperty("typeclass")
    public void setTypeclass(String typeclass) {
        this.typeclass = typeclass;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("childs")
    public List<Object> getChilds() {
        return childs;
    }

    @JsonProperty("childs")
    public void setChilds(List<Object> childs) {
        this.childs = childs;
    }

    @JsonProperty("keystorepath")
    public String getKeystorepath() {
        return keystorepath;
    }

    @JsonProperty("keystorepath")
    public void setKeystorepath(String keystorepath) {
        this.keystorepath = keystorepath;
    }

    @JsonProperty("keystorepwd")
    public String getKeystorepwd() {
        return keystorepwd;
    }

    @JsonProperty("keystorepwd")
    public void setKeystorepwd(String keystorepwd) {
        this.keystorepwd = keystorepwd;
    }

    @JsonProperty("keypassword")
    public String getKeypassword() {
        return keypassword;
    }

    @JsonProperty("keypassword")
    public void setKeypassword(String keypassword) {
        this.keypassword = keypassword;
    }

    @JsonProperty("truststorepath")
    public String getTruststorepath() {
        return truststorepath;
    }

    @JsonProperty("truststorepath")
    public void setTruststorepath(String truststorepath) {
        this.truststorepath = truststorepath;
    }

    @JsonProperty("truststorepwd")
    public String getTruststorepwd() {
        return truststorepwd;
    }

    @JsonProperty("truststorepwd")
    public void setTruststorepwd(String truststorepwd) {
        this.truststorepwd = truststorepwd;
    }

    @JsonProperty("transactionlogging")
    public String getTransactionlogging() {
        return transactionlogging;
    }

    @JsonProperty("transactionlogging")
    public void setTransactionlogging(String transactionlogging) {
        this.transactionlogging = transactionlogging;
    }

    @JsonProperty("logpayload")
    public String getLogpayload() {
        return logpayload;
    }

    @JsonProperty("logpayload")
    public void setLogpayload(String logpayload) {
        this.logpayload = logpayload;
    }

    @JsonProperty("owaspsanitizerrequired")
    public String getOwaspsanitizerrequired() {
        return owaspsanitizerrequired;
    }

    @JsonProperty("owaspsanitizerrequired")
    public void setOwaspsanitizerrequired(String owaspsanitizerrequired) {
        this.owaspsanitizerrequired = owaspsanitizerrequired;
    }

    @JsonProperty("mysqlcodecrequired")
    public String getMysqlcodecrequired() {
        return mysqlcodecrequired;
    }

    @JsonProperty("mysqlcodecrequired")
    public void setMysqlcodecrequired(String mysqlcodecrequired) {
        this.mysqlcodecrequired = mysqlcodecrequired;
    }

    @JsonProperty("oraclecodecrequired")
    public String getOraclecodecrequired() {
        return oraclecodecrequired;
    }

    @JsonProperty("oraclecodecrequired")
    public void setOraclecodecrequired(String oraclecodecrequired) {
        this.oraclecodecrequired = oraclecodecrequired;
    }

    @JsonProperty("percentcodecrequired")
    public String getPercentcodecrequired() {
        return percentcodecrequired;
    }

    @JsonProperty("percentcodecrequired")
    public void setPercentcodecrequired(String percentcodecrequired) {
        this.percentcodecrequired = percentcodecrequired;
    }

    @JsonProperty("pushbackstringrequired")
    public String getPushbackstringrequired() {
        return pushbackstringrequired;
    }

    @JsonProperty("pushbackstringrequired")
    public void setPushbackstringrequired(String pushbackstringrequired) {
        this.pushbackstringrequired = pushbackstringrequired;
    }

    @JsonProperty("htmlentitycodecrequired")
    public String getHtmlentitycodecrequired() {
        return htmlentitycodecrequired;
    }

    @JsonProperty("htmlentitycodecrequired")
    public void setHtmlentitycodecrequired(String htmlentitycodecrequired) {
        this.htmlentitycodecrequired = htmlentitycodecrequired;
    }

    @JsonProperty("xmlentitycodecrequired")
    public String getXmlentitycodecrequired() {
        return xmlentitycodecrequired;
    }

    @JsonProperty("xmlentitycodecrequired")
    public void setXmlentitycodecrequired(String xmlentitycodecrequired) {
        this.xmlentitycodecrequired = xmlentitycodecrequired;
    }

    @JsonProperty("javascriptcodecrequired")
    public String getJavascriptcodecrequired() {
        return javascriptcodecrequired;
    }

    @JsonProperty("javascriptcodecrequired")
    public void setJavascriptcodecrequired(String javascriptcodecrequired) {
        this.javascriptcodecrequired = javascriptcodecrequired;
    }

    @JsonProperty("defaultauthorization")
    public String getDefaultauthorization() {
        return defaultauthorization;
    }

    @JsonProperty("defaultauthorization")
    public void setDefaultauthorization(String defaultauthorization) {
        this.defaultauthorization = defaultauthorization;
    }

    @JsonProperty("servertoken")
    public String getServertoken() {
        return servertoken;
    }

    @JsonProperty("servertoken")
    public void setServertoken(String servertoken) {
        this.servertoken = servertoken;
    }

    @JsonProperty("mailfrom")
    public String getMailfrom() {
        return mailfrom;
    }

    @JsonProperty("mailfrom")
    public void setMailfrom(String mailfrom) {
        this.mailfrom = mailfrom;
    }

    @JsonProperty("portnumber")
    public String getPortnumber() {
        return portnumber;
    }

    @JsonProperty("portnumber")
    public void setPortnumber(String portnumber) {
        this.portnumber = portnumber;
    }

    @JsonProperty("hostname")
    public String getHostname() {
        return hostname;
    }

    @JsonProperty("hostname")
    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    @JsonProperty("sessiontimeout")
    public String getSessiontimeout() {
        return sessiontimeout;
    }

    @JsonProperty("sessiontimeout")
    public void setSessiontimeout(String sessiontimeout) {
        this.sessiontimeout = sessiontimeout;
    }

    @JsonProperty("servicetimeout")
    public String getServicetimeout() {
        return servicetimeout;
    }

    @JsonProperty("servicetimeout")
    public void setServicetimeout(String servicetimeout) {
        this.servicetimeout = servicetimeout;
    }

    @JsonProperty("logpath")
    public String getLogpath() {
        return logpath;
    }

    @JsonProperty("logpath")
    public void setLogpath(String logpath) {
        this.logpath = logpath;
    }

    @JsonProperty("protocol")
    public String getProtocol() {
        return protocol;
    }

    @JsonProperty("protocol")
    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    @JsonProperty("username")
    public String getUsername() {
        return username;
    }

    @JsonProperty("username")
    public void setUsername(String username) {
        this.username = username;
    }

    @JsonProperty("jasperfilepath")
    public String getJasperfilepath() {
        return jasperfilepath;
    }

    @JsonProperty("jasperfilepath")
    public void setJasperfilepath(String jasperfilepath) {
        this.jasperfilepath = jasperfilepath;
    }

    @JsonProperty("metadatadsn")
    public String getMetadatadsn() {
        return metadatadsn;
    }

    @JsonProperty("metadatadsn")
    public void setMetadatadsn(String metadatadsn) {
        this.metadatadsn = metadatadsn;
    }

    @JsonProperty("admindsn")
    public String getAdmindsn() {
        return admindsn;
    }

    @JsonProperty("admindsn")
    public void setAdmindsn(String admindsn) {
        this.admindsn = admindsn;
    }

    @JsonProperty("devicedestinationport")
    public String getDevicedestinationport() {
        return devicedestinationport;
    }

    @JsonProperty("devicedestinationport")
    public void setDevicedestinationport(String devicedestinationport) {
        this.devicedestinationport = devicedestinationport;
    }

    @JsonProperty("smsport")
    public String getSmsport() {
        return smsport;
    }

    @JsonProperty("smsport")
    public void setSmsport(String smsport) {
        this.smsport = smsport;
    }

    @JsonProperty("serversmsnumber")
    public String getServersmsnumber() {
        return serversmsnumber;
    }

    @JsonProperty("serversmsnumber")
    public void setServersmsnumber(String serversmsnumber) {
        this.serversmsnumber = serversmsnumber;
    }

    @JsonProperty("textmessagingserviceclass")
    public String getTextmessagingserviceclass() {
        return textmessagingserviceclass;
    }

    @JsonProperty("textmessagingserviceclass")
    public void setTextmessagingserviceclass(String textmessagingserviceclass) {
        this.textmessagingserviceclass = textmessagingserviceclass;
    }

    @JsonProperty("otplength")
    public String getOtplength() {
        return otplength;
    }

    @JsonProperty("otplength")
    public void setOtplength(String otplength) {
        this.otplength = otplength;
    }

    @JsonProperty("otpvalidcount")
    public String getOtpvalidcount() {
        return otpvalidcount;
    }

    @JsonProperty("otpvalidcount")
    public void setOtpvalidcount(String otpvalidcount) {
        this.otpvalidcount = otpvalidcount;
    }

    @JsonProperty("otpexpiry")
    public String getOtpexpiry() {
        return otpexpiry;
    }

    @JsonProperty("otpexpiry")
    public void setOtpexpiry(String otpexpiry) {
        this.otpexpiry = otpexpiry;
    }

    @JsonProperty("otpformat")
    public String getOtpformat() {
        return otpformat;
    }

    @JsonProperty("otpformat")
    public void setOtpformat(String otpformat) {
        this.otpformat = otpformat;
    }

    @JsonProperty("otpresend")
    public String getOtpresend() {
        return otpresend;
    }

    @JsonProperty("otpresend")
    public void setOtpresend(String otpresend) {
        this.otpresend = otpresend;
    }

    @JsonProperty("otpresendcount")
    public String getOtpresendcount() {
        return otpresendcount;
    }

    @JsonProperty("otpresendcount")
    public void setOtpresendcount(String otpresendcount) {
        this.otpresendcount = otpresendcount;
    }

    @JsonProperty("otpresendlocktime")
    public String getOtpresendlocktime() {
        return otpresendlocktime;
    }

    @JsonProperty("otpresendlocktime")
    public void setOtpresendlocktime(String otpresendlocktime) {
        this.otpresendlocktime = otpresendlocktime;
    }
    //added Logging details
    @JsonProperty("multitenancy")
    public String getMultitenancy() {
        return multitenancy;
    }

    @JsonProperty("multitenancy")
    public void setMultitenancy(String multitenancy) {
        this.multitenancy = multitenancy;
    }
   
    @JsonProperty("typeoflogging")
    public String getTypeoflogging() {
        return typeoflogging;
    }

    @JsonProperty("typeoflogging")
    public void setTypeoflogging(String typeoflogging) {
        this.typeoflogging = typeoflogging;
    }
   
    @JsonProperty("rolloverlog")
    public String getRolloverlog() {
        return rolloverlog;
    }

    @JsonProperty("rolloverlog")
    public void setRolloverlog(String rolloverlog) {
        this.rolloverlog = rolloverlog;
    }

    @JsonProperty("logfilemaxsize")
    public String getLogfilemaxsize() {
        return logfilemaxsize;
    }

    @JsonProperty("logfilemaxsize")
    public void setLogfilemaxsize(String logfilemaxsize) {
        this.logfilemaxsize = logfilemaxsize;
    }

    @JsonProperty("defrolloverstrategy")
    public String getDefrolloverstrategy() {
        return defrolloverstrategy;
    }

    @JsonProperty("defrolloverstrategy")
    public void setDefrolloverstrategy(String defrolloverstrategy) {
        this.defrolloverstrategy = defrolloverstrategy;
    }

    @JsonProperty("kafkaservers")
    public String getKafkaservers() {
        return kafkaservers;
    }

    @JsonProperty("kafkaservers")
    public void setKafkaservers(String kafkaservers) {
        this.kafkaservers = kafkaservers;
    }

    @JsonProperty("maxramalloc")
    public String getMaxramalloc() {
        return maxramalloc;
    }

    @JsonProperty("maxramalloc")
    public void setMaxramalloc(String maxramalloc) {
        this.maxramalloc = maxramalloc;
    }

    @JsonProperty("recordbatchsize")
    public String getRecordbatchsize() {
        return recordbatchsize;
    }

    @JsonProperty("recordbatchsize")
    public void setRecordbatchsize(String recordbatchsize) {
        this.recordbatchsize = recordbatchsize;
    }

    @JsonProperty("smsbeanslist")
    public List<Smsbeanslist> getSmsbeanslist() {
        return smsbeanslist;
    }

    @JsonProperty("smsbeanslist")
    public void setSmsbeanslist(List<Smsbeanslist> smsbeanslist) {
        this.smsbeanslist = smsbeanslist;
    }

    @JsonProperty("notifbeanslist")
    public List<Notifbeanslist> getNotifbeanslist() {
        return notifbeanslist;
    }

    @JsonProperty("notifbeanslist")
    public void setNotifbeanslist(List<Notifbeanslist> notifbeanslist) {
        this.notifbeanslist = notifbeanslist;
    }

    @JsonProperty("translationimplementationclass")
    public String getTranslationimplementationclass() {
        return translationimplementationclass;
    }

    @JsonProperty("translationimplementationclass")
    public void setTranslationimplementationclass(String translationimplementationclass) {
        this.translationimplementationclass = translationimplementationclass;
    }

    @JsonProperty("publickey")
    public String getPublickey() {
        return publickey;
    }

    @JsonProperty("publickey")
    public void setPublickey(String publickey) {
        this.publickey = publickey;
    }

    @JsonProperty("privatekey")
    public String getPrivatekey() {
        return privatekey;
    }

    @JsonProperty("privatekey")
    public void setPrivatekey(String privatekey) {
        this.privatekey = privatekey;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
