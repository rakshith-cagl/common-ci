package com.iexceed.ci.iospreference;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "typeclass",
    "name",
    "type",
    "childs",
    "iosbundleid",
    "ioswatchenabled",
    "iosgood",
    "ppuuid",
    "ppname",
    "iosdevelopmentteam",
    "iosdeployementmode",
    "iosbuildtype",
    "iphonecolor",
    "statusbarcolor",
    "statusbarstyle"
})
public class IosPref {
	@JsonProperty("typeclass")
    private String typeclass;
    @JsonProperty("name")
    private String name;
    @JsonProperty("type")
    private String type;
    @JsonProperty("childs")
    private List<Object> childs = null;
    @JsonProperty("iosbundleid")
    private String iosbundleid;
    @JsonProperty("ioswatchenabled")
    private String ioswatchenabled;
    @JsonProperty("iosgood")
    private String iosgood;
    @JsonProperty("ppuuid")
    private String ppuuid;
    @JsonProperty("ppname")
    private String ppname;
    @JsonProperty("iosdevelopmentteam")
    private String iosdevelopmentteam;
    @JsonProperty("iosdeploymentmethod")
    private String iosdeploymentmethod;
    @JsonProperty("iosbuildtype")
    private String iosbuildtype;
    @JsonProperty("iphonecolor")
    private String iphonecolor;
    @JsonProperty("statusbarcolor")
    private String statusbarcolor;
    @JsonProperty("statusbarstyle")
    private String statusbarstyle;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    
    @JsonProperty("typeclass")
    public String getTypeclass() {
        return typeclass;
    }

    @JsonProperty("typeclass")
    public void setTypeclass(String typeclass) {
        this.typeclass = typeclass;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }
    
    @JsonProperty("childs")
    public List<Object> getChilds() {
        return childs;
    }

    @JsonProperty("childs")
    public void setChilds(List<Object> childs) {
        this.childs = childs;
    }
    
    @JsonProperty("iosbundleid")
    public String getiosbundleid() {
        return iosbundleid;
    }

    @JsonProperty("iosbundleid")
    public void setiosbundleid(String iosbundleid) {
        this.iosbundleid = iosbundleid;
    }
    
    @JsonProperty("ioswatchenabled")
    public String getioswatchenabled() {
        return ioswatchenabled;
    }

    @JsonProperty("ioswatchenabled")
    public void setioswatchenabled(String ioswatchenabled) {
        this.ioswatchenabled = ioswatchenabled;
    }
    
    @JsonProperty("iosgood")
    public String getiosgood() {
        return iosgood;
    }

    @JsonProperty("iosgood")
    public void setiosgood(String iosgood) {
        this.iosgood = iosgood;
    }
    
    @JsonProperty("ppuuid")
    public String getppuuid() {
        return ppuuid;
    }

    @JsonProperty("ppuuid")
    public void setppuuid(String ppuuid) {
        this.ppuuid = ppuuid;
    }
    
    @JsonProperty("ppname")
    public String getppname() {
        return ppname;
    }

    @JsonProperty("ppname")
    public void setppname(String ppname) {
        this.ppname = ppname;
    }
    
    @JsonProperty("developmentteam")
    public String getDevelopmentteam() {
        return iosdevelopmentteam;
    }

    @JsonProperty("developmentteam")
    public void setDevelopmentteam(String developmentteam) {
        this.iosdevelopmentteam = developmentteam;
    }
    
    @JsonProperty("deployementmode")
    public String getDeployementmode() {
        return iosdeploymentmethod;
    }

    @JsonProperty("deployementmode")
    public void setDeployementmode(String deployementmode) {
        this.iosdeploymentmethod = deployementmode;
    }
    
    @JsonProperty("iphonecolor")
    public String getiphonecolor() {
        return iphonecolor;
    }

    @JsonProperty("iphonecolor")
    public void setiphonecolor(String iphonecolor) {
        this.iphonecolor = iphonecolor;
    }
    
    @JsonProperty("statusbarcolor")
    public String getstatusbarcolor() {
        return statusbarcolor;
    }

    @JsonProperty("statusbarcolor")
    public void setstatusbarcolor(String statusbarcolor) {
        this.statusbarcolor = statusbarcolor;
    }
    
    @JsonProperty("statusbarstyle")
    public String getstatusbarstyle() {
        return statusbarstyle;
    }

    @JsonProperty("statusbarstyle")
    public void setstatusbarstyle(String statusbarstyle) {
        this.statusbarstyle = statusbarstyle;
    }
    
    @JsonProperty("iosbuildtype")
    public String getiosbuildtype() {
        return iosbuildtype;
    }

    @JsonProperty("iosbuildtype")
    public void setiosbuildtype(String iosbuildtype) {
        this.iosbuildtype = iosbuildtype;
    }
    
    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
}
