
package com.iexceed.ci.microappdtls;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "typeclass",
    "name",
    "type",
    "microapps",
    "microappsfolder"
})
public class MicroAppMain {
	
	
    @Override
	public String toString() {
		return "MicroAppMain [typeclass=" + typeclass + ", name=" + name + ", type=" + type + ", microapps=" + microapps
				+ ", microappsfolder=" + microappsfolder + ", additionalProperties=" + additionalProperties + "]";
	}

	@JsonProperty("typeclass")
    private String typeclass;
    @JsonProperty("name")
    private String name;
    @JsonProperty("type")
    private String type;
    @JsonProperty("microapps")
    private List<MicroappList> microapps = null;
    @JsonProperty("microappsfolder")
    private String microappsfolder;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("typeclass")
    public String getTypeclass() {
        return typeclass;
    }

    @JsonProperty("typeclass")
    public void setTypeclass(String typeclass) {
        this.typeclass = typeclass;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("microapps")
    public List<MicroappList> getMicroapps() {
        return microapps;
    }

    @JsonProperty("microapps")
    public void setMicroapps(List<MicroappList> microapps) {
        this.microapps = microapps;
    }

    @JsonProperty("microappsfolder")
    public String getMicroappsfolder() {
        return microappsfolder;
    }

    @JsonProperty("microappsfolder")
    public void setMicroappsfolder(String microappsfolder) {
        this.microappsfolder = microappsfolder;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
