package com.iexceed.ci.generatefile;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.iexceed.ci.androidpreference.AndroidPref;
import com.iexceed.ci.baseapp.BaseApp;
import com.iexceed.ci.buildapp.App;
import com.iexceed.ci.buildapp.BuildApp;
import com.iexceed.ci.buildapp.Os;
import com.iexceed.ci.environment.Environment;
import com.iexceed.ci.environment.Environmentvariablefile;
import com.iexceed.ci.iospreference.IosPref;
import com.iexceed.ci.jenkinsrelatedproperties.JenkinsProperties;
import com.iexceed.ci.languages.Languages;
import com.iexceed.ci.languages.Languagesvariablefile;
import com.iexceed.ci.microappdtls.MicroAppMain;
import com.iexceed.ci.microappdtls.MicroappList;
import com.iexceed.ci.serverapp.BuildServer;
import com.iexceed.ci.serverapp.OsServer;
import com.iexceed.ci.serverpreference.ServerPreference;
import com.iexceed.ci.webpreference.WebPref;



public class GenerateFiles {

	static ObjectMapper mapper = new ObjectMapper();
	private static final Logger LOG= Logger.getLogger(GenerateFiles.class.getName());
	private static final String FILE_DELETE = "delete";
	private static final String FILE_CREATE = "create";

	
	public static void main(String[] args) {
		try {
			/*
			 * Application path till the folder which contains serverPrefFilePathbaseapp and
			 * microapps
			 */
			String projectFilePath = args[0];
			LOG.info("Project Path :" + projectFilePath);
			/* Environment to build ENV,UAT,PROD */
			String environment = args[1];
			LOG.info("BaseApp Name :" + environment);
			/* Application build mode : TESTING,DEBUG,PROD */
			String buildMode = args[2];
			LOG.info("Build Mode :" + buildMode);
			/* Which war to build web,server,web-server */
			String buildOnly = args[3].toLowerCase();
			LOG.info("Build Only :" + buildOnly);
			String serverBaseApps = "";
			String jenkinsUiPath = "";
			if (buildOnly.equalsIgnoreCase("server") || buildOnly.equalsIgnoreCase("webserver")
					|| buildOnly.equalsIgnoreCase("webapkserver") || buildOnly.equalsIgnoreCase("webapkiosserver")) {
				serverBaseApps = args[4];
				LOG.info("Combined server projects :" + serverBaseApps);

				jenkinsUiPath = args[5];
				LOG.info("jenkins path :" + jenkinsUiPath);
			}
			String jenkinsProp = projectFilePath + "/Properties.json";
			JenkinsProperties objJenkinsProp = mapper.readValue(new File(jenkinsProp), JenkinsProperties.class);
			System.out.println(objJenkinsProp);

			String baseAppName = objJenkinsProp.getBaseAppName();
			String baseAppPropFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + ".apzprj";
			LOG.info("BaseApp Path :" + baseAppPropFilePath);
			
			String microAppPropFilePath = "";
			if("Y".equalsIgnoreCase(objJenkinsProp.getIncludeMicroApp())) {
			 	microAppPropFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + '/'
					+ "microapps.apzmicroapps";
			}
			LOG.info("MicroApp Path :" + microAppPropFilePath);
		
			String envPropFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName
					+ "/staticdata/environments/" + environment + ".apzenv";
			LOG.info("Env Path :" + envPropFilePath);
			
			String langsPropFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + "/staticdata/languages.apzlangs";
			LOG.info("Languages Path :" + langsPropFilePath);

			String webOsFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + "/osprefs/web.apzosprefs";
			LOG.info("Web os path " + webOsFilePath);
			
			String serverPrefFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + "/serverpreferences.apzsrvprefs";
			LOG.info("Server Pref path " + serverPrefFilePath);
			
			String androidPrefFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + "/osprefs/android.apzosprefs";
			
			String iosPrefFilePath = projectFilePath + '/' + baseAppName + '/' + baseAppName + "/osprefs/ios.apzosprefs";
			
			//PropertiesDtls propertiesObj = new PropertiesDtls(projectFilePath,baseAppName,buildMode,objJenkinsProp,baseAppPropFilePath,microAppPropFilePath,envPropFilePath,webOsFilePath,serverPrefFilePath,androidPrefFilePath,objJenkinsProp.getIncludeMicroApp());

			PropertiesDtls propertiesObj = new PropertiesDtls(projectFilePath, baseAppName, buildMode, objJenkinsProp,
					baseAppPropFilePath, microAppPropFilePath, envPropFilePath, webOsFilePath, serverPrefFilePath,
					androidPrefFilePath, iosPrefFilePath, objJenkinsProp.getIncludeMicroApp(), langsPropFilePath, serverBaseApps, jenkinsUiPath);
			System.out.println(propertiesObj);
			
			File buildAppFile = new File(propertiesObj.getObjJenkinsProp().getBuildAppPath());
			File buildServerFile = new File(propertiesObj.getObjJenkinsProp().getBuildServerPath());
			if(buildAppFile.exists() && buildServerFile.exists()){
				fileOperationHandler(buildAppFile,FILE_DELETE);
				fileOperationHandler(buildServerFile,FILE_DELETE);
			}else if(buildAppFile.exists()){
				fileOperationHandler(buildAppFile,FILE_DELETE);
			}else if(buildServerFile.exists()){
				fileOperationHandler(buildServerFile,FILE_DELETE);
			}
			
			if(buildOnly.equalsIgnoreCase("web")){
				generateBuildAppDataWeb(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), propertiesObj.getObjWebOSProp(),propertiesObj.getObjServerPrefProp(),propertiesObj, objJenkinsProp.getIncludeMicroApp());
			}else if(buildOnly.equalsIgnoreCase("server")){
				generateServerAppData(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), propertiesObj.getObjServerPrefProp(),propertiesObj, objJenkinsProp.getIncludeMicroApp());
			}else if(buildOnly.equalsIgnoreCase("webserver")){
				generateBuildAppDataWeb(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), propertiesObj.getObjWebOSProp(),propertiesObj.getObjServerPrefProp(),propertiesObj, objJenkinsProp.getIncludeMicroApp());
				generateServerAppData(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), propertiesObj.getObjServerPrefProp(),propertiesObj, objJenkinsProp.getIncludeMicroApp());
			}else if(buildOnly.equalsIgnoreCase("apk")){
				WebPref webPrefDummy = new WebPref();
				webPrefDummy = null;
				IosPref iosPrefDummy = new IosPref();
				iosPrefDummy = null;
				generateBuildAppDataWebAPK(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), webPrefDummy,propertiesObj.getObjServerPrefProp(),propertiesObj,(AndroidPref) propertiesObj.getObjAndroidProp(), iosPrefDummy, objJenkinsProp.getIncludeMicroApp());
				LOG.info("apk");
			}else if(buildOnly.equalsIgnoreCase("apkios")){
				LOG.info("apkios");
				WebPref webPrefDummy = new WebPref();
				webPrefDummy = null;
				generateBuildAppDataWebAPK(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), webPrefDummy,propertiesObj.getObjServerPrefProp(),propertiesObj,(AndroidPref) propertiesObj.getObjAndroidProp(), (IosPref) propertiesObj.getObjIosProp(), objJenkinsProp.getIncludeMicroApp());
			}else if(buildOnly.equalsIgnoreCase("ios")){
				LOG.info("ios");
				WebPref webPrefDummy = new WebPref();
				webPrefDummy = null;
				generateBuildIosData(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), webPrefDummy,propertiesObj.getObjServerPrefProp(),propertiesObj,(IosPref) propertiesObj.getObjIosProp(), objJenkinsProp.getIncludeMicroApp());
			}else if(buildOnly.equalsIgnoreCase("webapk")){
				LOG.info("webapk");
				IosPref iosPrefDummy = new IosPref();
				iosPrefDummy = null;
				generateBuildAppDataWebAPK(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), propertiesObj.getObjWebOSProp(),propertiesObj.getObjServerPrefProp(),propertiesObj,(AndroidPref) propertiesObj.getObjAndroidProp(), iosPrefDummy, objJenkinsProp.getIncludeMicroApp());
			}else if(buildOnly.equalsIgnoreCase("webapkserver")){
				LOG.info("webapkserver");
				IosPref iosPrefDummy = new IosPref();
				iosPrefDummy = null;
				generateBuildAppDataWebAPK(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), propertiesObj.getObjWebOSProp(),propertiesObj.getObjServerPrefProp(),propertiesObj,(AndroidPref) propertiesObj.getObjAndroidProp(), iosPrefDummy, objJenkinsProp.getIncludeMicroApp());
				generateServerAppData(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), propertiesObj.getObjServerPrefProp(),propertiesObj, objJenkinsProp.getIncludeMicroApp());
			}else if(buildOnly.equalsIgnoreCase("webapkiosserver")){
				LOG.info("webapkiosserver");
				generateBuildAppDataWebAPK(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), propertiesObj.getObjWebOSProp(),propertiesObj.getObjServerPrefProp(),propertiesObj,(AndroidPref) propertiesObj.getObjAndroidProp(), (IosPref) propertiesObj.getObjIosProp(), objJenkinsProp.getIncludeMicroApp());
				generateServerAppData(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), propertiesObj.getObjServerPrefProp(),propertiesObj, objJenkinsProp.getIncludeMicroApp());
			}else if(buildOnly.equalsIgnoreCase("webapkios")){
				LOG.info("webapkios");
				generateBuildAppDataWebAPK(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), propertiesObj.getObjWebOSProp(),propertiesObj.getObjServerPrefProp(),propertiesObj,(AndroidPref) propertiesObj.getObjAndroidProp(), (IosPref) propertiesObj.getObjIosProp(), objJenkinsProp.getIncludeMicroApp());
			}else if(buildOnly.equalsIgnoreCase("webios")){
				LOG.info("webios");
				AndroidPref andPrefDummy = new AndroidPref();
				andPrefDummy = null;
				generateBuildAppDataWebAPK(propertiesObj.getObjBaseApp(), propertiesObj.getObjMicroApp(), propertiesObj.getObjEnvProp(), propertiesObj.getObjWebOSProp(),propertiesObj.getObjServerPrefProp(),propertiesObj,andPrefDummy, (IosPref) propertiesObj.getObjIosProp(), objJenkinsProp.getIncludeMicroApp());
			}else{
				LOG.info("Build mode not sent");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}

	public static void generateBuildAppDataWeb(BaseApp baseApp, MicroAppMain microApp, Environment environment,
			WebPref webPref,ServerPreference serverPreference,PropertiesDtls propertiesObj, String includeMicroapp) {
		try {
			BuildApp buildAppData = new BuildApp();
			buildAppData.setUser("ci");
			buildAppData.setStatus("S");
			buildAppData.setSimulator(false);
			String serverUrl = "";
			List<Environmentvariablefile> environmentFileList = environment.getEnvironmentvariablefile();
			if (null != environmentFileList) {
				for (int i = 0; i < environmentFileList.size(); i++) {
					if (environmentFileList.get(i).getKeyname().equalsIgnoreCase("APPZILLONSERVER")) {
						serverUrl = environmentFileList.get(i).getValue();
					}
				}
				buildAppData.setServerurl(serverUrl);
			} else {
				buildAppData.setServerurl(baseApp.getServerurl());
			}
			buildAppData.setBuildfolder(propertiesObj.getObjJenkinsProp().getAppzillonBuildPath());
			buildAppData.setPreLoadDependencies(false);
			buildAppData.setLoadAllOnStartup(false);
			buildAppData.setBuildmode(propertiesObj.getBuildMode());
			buildAppData.setEnvobj(environment);
			buildAppData.setEnablemockserver(false);
			buildAppData.setDataintegrity(baseApp.getDataintegrity());
			buildAppData.setEncryptionreqd(baseApp.getEncryptionreqd());
			buildAppData.setPublicKey(serverPreference.getPublickey());
			List<String> langs = new ArrayList<>();
			JSONObject containerObject = new JSONObject(propertiesObj.getObjLangsProp());
			JSONObject labelDataJson = containerObject.getJSONObject("language");
			JSONArray list = new JSONArray();
			list = (JSONArray) labelDataJson.get("languages");
			for (int j = 0; j < list.length(); j++) {
				JSONObject rec = list.getJSONObject(j);
				String name = rec.getString("name");
				langs.add(name);
			}
			buildAppData.setLangs(langs);
			buildAppData.setOss(generatebuildAppOssObject(propertiesObj,baseApp,webPref));
			if("Y".equalsIgnoreCase(includeMicroapp)) {
				buildAppData.setApps(generateAppObject(baseApp,microApp,propertiesObj));
			}else {
				List<App> apps = new ArrayList<>();
				apps.add(generateBaseAppObject(baseApp,propertiesObj));
				buildAppData.setApps(apps);
			}
			File buildAppFile = new File(propertiesObj.getObjJenkinsProp().getBuildAppPath());
			fileOperationHandler(buildAppFile,FILE_CREATE);
			mapper.writerWithDefaultPrettyPrinter().writeValue(new File(propertiesObj.getObjJenkinsProp().getBuildAppPath()),buildAppData);
			LOG.info("Write to file successful");
			//Check if Web file exists
			if (buildAppFile.exists()) {
				LOG.info("Web preferences json file exists");
			} else {
				LOG.info("Web preferences json file is missing");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}
	
	public static void generateBuildAppDataWebAPK(BaseApp baseApp, MicroAppMain microApp, Environment environment,
			WebPref webPref,ServerPreference serverPreference,PropertiesDtls propertiesObj,AndroidPref androidPref, IosPref iosPref, String includeMicroApp) {
		try {
			BuildApp buildAppData = new BuildApp();
			buildAppData.setUser("ci");
			buildAppData.setStatus("S");
			buildAppData.setSimulator(false);
			String serverUrl = "";
			List<Environmentvariablefile> environmentFileList = environment.getEnvironmentvariablefile();
			if (null != environmentFileList) {
				for (int i = 0; i < environmentFileList.size(); i++) {
					if (environmentFileList.get(i).getKeyname().equalsIgnoreCase("APPZILLONSERVER")) {
						serverUrl = environmentFileList.get(i).getValue();
					}
				}
				buildAppData.setServerurl(serverUrl);
			} else {
				buildAppData.setServerurl(baseApp.getServerurl());
			}
			buildAppData.setBuildfolder(propertiesObj.getObjJenkinsProp().getAppzillonBuildPath());
			buildAppData.setPreLoadDependencies(false);
			buildAppData.setLoadAllOnStartup(false);
			buildAppData.setBuildmode(propertiesObj.getBuildMode());
			buildAppData.setEnvobj(environment);
			buildAppData.setEnablemockserver(false);
			buildAppData.setDataintegrity(baseApp.getDataintegrity());
			buildAppData.setEncryptionreqd(baseApp.getEncryptionreqd());
			buildAppData.setPublicKey(serverPreference.getPublickey());
			List<String> langs = new ArrayList<>();
			JSONObject containerObject = new JSONObject(propertiesObj.getObjLangsProp());
			JSONObject labelDataJson = containerObject.getJSONObject("language");
			JSONArray list = new JSONArray();
			list = (JSONArray) labelDataJson.get("languages");
			for (int j = 0; j < list.length(); j++) {
				JSONObject rec = list.getJSONObject(j);
				String name = rec.getString("name");
				langs.add(name);
			}
			buildAppData.setLangs(langs);
			buildAppData.setOss(generatebuildAppOssObject(propertiesObj,baseApp,webPref,androidPref,iosPref));
			buildAppData.setApps(generateAppObject(baseApp,microApp,propertiesObj));
			File buildAppFile = new File(propertiesObj.getObjJenkinsProp().getBuildAppPath());
			fileOperationHandler(buildAppFile,FILE_CREATE);
			mapper.writerWithDefaultPrettyPrinter().writeValue(new File(propertiesObj.getObjJenkinsProp().getBuildAppPath()),buildAppData);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}
	
	public static void generateBuildIosData(BaseApp baseApp, MicroAppMain microApp, Environment environment,
			WebPref webPref,ServerPreference serverPreference,PropertiesDtls propertiesObj,IosPref iosPref, String includeMicroApp) {
		try {
			BuildApp buildAppData = new BuildApp();
			buildAppData.setUser("ci");
			buildAppData.setStatus("S");
			buildAppData.setSimulator(false);
			String serverUrl = "";
			List<Environmentvariablefile> environmentFileList = environment.getEnvironmentvariablefile();
			if (null != environmentFileList) {
				for (int i = 0; i < environmentFileList.size(); i++) {
					if (environmentFileList.get(i).getKeyname().equalsIgnoreCase("APPZILLONSERVER")) {
						serverUrl = environmentFileList.get(i).getValue();
					}
				}
				buildAppData.setServerurl(serverUrl);
			} else {
				buildAppData.setServerurl(baseApp.getServerurl());
			}
			buildAppData.setBuildfolder(propertiesObj.getObjJenkinsProp().getAppzillonBuildPath());
			buildAppData.setPreLoadDependencies(false);
			buildAppData.setLoadAllOnStartup(false);
			buildAppData.setBuildmode(propertiesObj.getBuildMode());
			buildAppData.setEnvobj(environment);
			buildAppData.setEnablemockserver(false);
			buildAppData.setDataintegrity(baseApp.getDataintegrity());
			buildAppData.setEncryptionreqd(baseApp.getEncryptionreqd());
			buildAppData.setPublicKey(serverPreference.getPublickey());
			List<String> langs = new ArrayList<>();
			JSONObject containerObject = new JSONObject(propertiesObj.getObjLangsProp());
			JSONObject labelDataJson = containerObject.getJSONObject("language");
			JSONArray list = new JSONArray();
			list = (JSONArray) labelDataJson.get("languages");
			for (int j = 0; j < list.length(); j++) {
				JSONObject rec = list.getJSONObject(j);
				String name = rec.getString("name");
				langs.add(name);
			}
			buildAppData.setLangs(langs);
			buildAppData.setOss(generatebuildAppIosObject(propertiesObj,baseApp, iosPref));
			buildAppData.setApps(generateAppObject(baseApp,microApp,propertiesObj));
			File buildAppFile = new File(propertiesObj.getObjJenkinsProp().getBuildAppPath());
			fileOperationHandler(buildAppFile,FILE_CREATE);
			mapper.writerWithDefaultPrettyPrinter().writeValue(new File(propertiesObj.getObjJenkinsProp().getBuildAppPath()),buildAppData);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}
	
	public static void generateServerAppData (BaseApp baseApp, MicroAppMain microApp, Environment environment, ServerPreference serverPref,PropertiesDtls propertiesObj, String includeMicroApp){
		try{
			BuildServer serverAppData = new BuildServer(); 
			serverAppData.setUser("ci");
			serverAppData.setStatus("S");
			serverAppData.setRebuildstatus("N");
			JSONArray baseAppDtls = new JSONArray(propertiesObj.getServerBaseApps());
			/*Need to make Dynamic*/
			serverAppData.setBuildfolder(propertiesObj.getObjJenkinsProp().getAppzillonBuildPath());
			serverAppData.setBuildmode(propertiesObj.getBuildMode());
			serverAppData.setDataintegrity(baseApp.getDataintegrity());
			JSONObject microAppsWithBaseAppNode = new JSONObject();
			for (int j = 0; j < baseAppDtls.length(); j++) {
				JSONObject baseAppDtl = baseAppDtls.getJSONObject(j);
				JSONArray microAppData = new JSONArray();
				if("Y".equalsIgnoreCase(includeMicroApp)) {
					String microAppPropFilePath = "";
					microAppPropFilePath = propertiesObj.getProjectFilePath() + '/' + baseAppDtl.get("name") + '/' + baseAppDtl.get("name") + '/'
							+ "microapps.apzmicroapps";
					propertiesObj.getObjMicroApp().setMicroappsfolder(propertiesObj.getProjectFilePath()+ '/' + baseAppDtl.get("name") +"/MicroApp");
					MicroAppMain lmicroapp = mapper.readValue(new File(microAppPropFilePath), MicroAppMain.class);
					mapper.writeValue(new File(microAppPropFilePath),lmicroapp);

					if(lmicroapp.getMicroapps() != null){
						List<MicroappList> microAppList = lmicroapp.getMicroapps();
						for (int i = 0; i < microAppList.size(); i++) {
							JSONObject microAppJson = new JSONObject();
							microAppJson.put("id", microAppList.get(i).getAppid());
							microAppJson.put("name", microAppList.get(i).getName());
							microAppJson.put("folder", propertiesObj.getProjectFilePath() +'/' + baseAppDtl.get("name") + "/MicroApp/" + microAppList.get(i).getName());
							microAppData.put(microAppJson);
						 }
					}
			}
			microAppsWithBaseAppNode.put(baseAppDtl.get("name").toString(), microAppData);
			JsonNode baseWithMicroNode = mapper.readTree(microAppsWithBaseAppNode.toString());
			serverAppData.setPrjApps(baseWithMicroNode);
			}
			//PrjApps prjApps = new PrjApps();
			//prjApps.setAxisBaseApp(baseWithMicroNode);
			serverAppData.setEnvobj(environment);
			List<App> apps = new ArrayList<>();
			for (int i = 0; i < baseAppDtls.length(); i++) {
				JSONObject baseAppDtl = baseAppDtls.getJSONObject(i);
				apps.add(generateBaseAppObject(baseAppDtl, propertiesObj));
			}
			// apps.add(generateBaseAppObject(baseApp, propertiesObj));
			serverAppData.setApps(apps);
			serverAppData.setOss(generatebuildServerOssObject(serverPref, environment, propertiesObj, baseApp));
			File buildServerFile = new File(propertiesObj.getObjJenkinsProp().getBuildServerPath());
			fileOperationHandler(buildServerFile,FILE_CREATE);
			mapper.writerWithDefaultPrettyPrinter().writeValue(new File(propertiesObj.getObjJenkinsProp().getBuildServerPath()),serverAppData);
			LOG.info("Write to Server file successful");
			//Check if Server file exists
			if (buildServerFile.exists()) {
				LOG.info("Server preferences json file exists");
			} else {
				LOG.info("Server preferences json file is missing");
			}
		}catch(Exception e){
			e.printStackTrace();
			System.exit(-1);
		}
	}
	
	public static App generateBaseAppObject(JSONObject baseAppDtl, PropertiesDtls propertiesObj) {
		App baseapp = new App();
		baseapp.setId(baseAppDtl.getString("appId"));
		baseapp.setName(baseAppDtl.getString("name"));
		baseapp.setFolder(propertiesObj.getJenkinsUiPath() + '/' + baseAppDtl.getString("name"));
		return baseapp;
	}

	public static App generateBaseAppObject (BaseApp baseApp, PropertiesDtls propertiesObj){
		App baseapp = new App();
		baseapp.setId(baseApp.getAppid());
		baseapp.setName(baseApp.getName());
		baseapp.setFolder(propertiesObj.getProjectFilePath() + '/' + baseApp.getName());
		//baseapp.setFolder(propertiesObj.getProjectFilePath());
		return baseapp;
	}
	
	public static  List<App> generateAppObject (BaseApp baseApp,MicroAppMain microApp,PropertiesDtls propertiesObj){
		List<App> apps = new ArrayList<>();
		LOG.info("MicroApp : "+microApp.toString());
		if(microApp.getMicroapps() != null){
			List<MicroappList> microAppList = microApp.getMicroapps();
			apps.add(generateBaseAppObject(baseApp,propertiesObj));
			LOG.info("MicroAppList size : "+microAppList.size());
			for (int i = 0; i < microAppList.size(); i++) {
				App microapp = new App();
				microapp.setId(microAppList.get(i).getAppid());
				microapp.setName(microAppList.get(i).getName());
				microapp.setFolder(propertiesObj.getProjectFilePath() +'/' + baseApp.getName() + "/MicroApp/" + microAppList.get(i).getName());
				apps.add(microapp);
			}
		}else{
			apps.add(generateBaseAppObject(baseApp,propertiesObj));
		}
		return apps;
	}
	
	public static List<Os> generatebuildAppOssObject (PropertiesDtls propertiesObj,BaseApp baseApp,WebPref webPref){
		List<Os> oss = new ArrayList<>();
		Os osspref = new Os();
		osspref.setName("WEB");
		osspref.setTypeclass("WEB");
		osspref.setState("YETTOSTART");
		osspref.setStatus("S");
		osspref.setBuildmode(webPref.getBuildmode());
		osspref.setWarfilename(baseApp.getName());
		osspref.setLogdir(webPref.getWeblogdir());
		osspref.setSettingspath(webPref.getWebusersettingspath());
		osspref.setHttpkeystorepath(webPref.getKeystorepath());
		osspref.setKeystorepassword(webPref.getKeystorepassword());
		osspref.setTruststorepath(webPref.getTruststorepath());
		osspref.setBundlewebprops(propertiesObj.getObjJenkinsProp().getBundleWebProps());
		osspref.setCodecoverage(propertiesObj.getObjJenkinsProp().getCodecoverage());
		osspref.setSessionstickyness(propertiesObj.getObjJenkinsProp().getDisableSessionStickyness());
		osspref.setHttponlycookie(webPref.getHttponlycookie());
		osspref.setSecurecookie(webPref.getSecurecookie());
		osspref.setCsrfprevention(webPref.getCsrfprevention());
		osspref.setSafekey(webPref.getSafekey());
		osspref.setTruststorepwd(webPref.getTruststorepwd());
		osspref.setKeepsignedin(webPref.getKeepsignedin());
		osspref.setCookieage("");
		oss.add(osspref);
		return oss;
	}
	
	public static List<Os> generatebuildAppIosObject (PropertiesDtls propertiesObj,BaseApp baseApp,IosPref iosPref){
		List<Os> oss = new ArrayList<>();
		Os ossIosPref = new Os();
		ossIosPref.setName("IOS");
		ossIosPref.setTypeclass("IOS");
		ossIosPref.setState("YETTOSTART");
		ossIosPref.setStatus("S");
		ossIosPref.setppuuid(iosPref.getppuuid());
		ossIosPref.setppname(iosPref.getppname());
		ossIosPref.setDevelopmentteam(iosPref.getDevelopmentteam());
		ossIosPref.setDeployementmode(iosPref.getDeployementmode());
		ossIosPref.setIosbuildtype(iosPref.getiosbuildtype());
		oss.add(ossIosPref);
		return oss;
	}
	
	public static List<Os> generatebuildAppOssObject (PropertiesDtls propertiesObj,BaseApp baseApp,WebPref webPref,AndroidPref androidPref,IosPref iosPref){
		List<Os> oss = new ArrayList<>();
		if(webPref  != null){
		Os osspref = new Os();
		osspref.setName("WEB");
		osspref.setTypeclass("WEB");
		osspref.setState("YETTOSTART");
		osspref.setStatus("S");
		osspref.setBuildmode(webPref.getBuildmode());
		osspref.setWarfilename(baseApp.getName());
		osspref.setLogdir(webPref.getWeblogdir());
		osspref.setSettingspath(webPref.getWebusersettingspath());
		osspref.setHttpkeystorepath(webPref.getKeystorepath());
		osspref.setKeystorepassword(webPref.getKeystorepassword());
		osspref.setTruststorepath(webPref.getTruststorepath());
		osspref.setBundlewebprops(propertiesObj.getObjJenkinsProp().getBundleWebProps());
		osspref.setCodecoverage(propertiesObj.getObjJenkinsProp().getCodecoverage());
		osspref.setSessionstickyness(propertiesObj.getObjJenkinsProp().getDisableSessionStickyness());
		osspref.setHttponlycookie(webPref.getHttponlycookie());
		osspref.setSecurecookie(webPref.getSecurecookie());
		osspref.setCsrfprevention(webPref.getCsrfprevention());
		osspref.setSafekey(webPref.getSafekey());
		osspref.setTruststorepwd(webPref.getTruststorepwd());
		osspref.setKeepsignedin(webPref.getKeepsignedin());
		osspref.setCookieage("");
		oss.add(osspref);
		}
		if(androidPref  != null){
		Os ossAndroidpref = new Os();
		ossAndroidpref.setName("ANDROID");
		ossAndroidpref.setTypeclass("ANDROID");
		ossAndroidpref.setState("YETTOSTART");
		ossAndroidpref.setStatus("S");
		ossAndroidpref.setKeystorepath(androidPref.getAndkeystore());
		ossAndroidpref.setKeystorepassword(androidPref.getAndkeystorepswrd());
		ossAndroidpref.setKeystorealias(androidPref.getAndkeystorealias());
		ossAndroidpref.setKeystorealiaspwd(androidPref.getAndkeystorealiaspswrd());
		ossAndroidpref.setObfuscation(androidPref.getAndobfuscation());
		ossAndroidpref.setBuildinstaller("APK");
		ossAndroidpref.setBuildtypeuniversal("Y");
		ossAndroidpref.setBuildtype32bitarm("N");
		ossAndroidpref.setBuildtype32bitx86("N");
		ossAndroidpref.setBuildtype64bitarm("N");
		ossAndroidpref.setBuildtype64bitx86("N");
		ossAndroidpref.setBuildtypehuawei("N");
		ossAndroidpref.setBuildsdktype("KOTLIN");
		ossAndroidpref.setGdapplicationid("");
		ossAndroidpref.setGdapplicationversion("");
		oss.add(ossAndroidpref);
		}
		if(iosPref  != null){
		Os ossIosPref = new Os();
		ossIosPref.setName("IOS");
		ossIosPref.setTypeclass("IOS");
		ossIosPref.setState("YETTOSTART");
		ossIosPref.setStatus("S");
		ossIosPref.setppuuid(iosPref.getppuuid());
		ossIosPref.setppname(iosPref.getppname());
		ossIosPref.setDevelopmentteam(iosPref.getDevelopmentteam());
		ossIosPref.setDeployementmode(iosPref.getDeployementmode());
		ossIosPref.setIosbuildtype(iosPref.getiosbuildtype());
		oss.add(ossIosPref);
		}
		return oss;
	}

	public static List<OsServer> generatebuildServerOssObject(ServerPreference serverPreference,
			Environment environment, PropertiesDtls propertiesObj, BaseApp baseApp) {
		List<OsServer> ossServer = new ArrayList<>();
		OsServer ossPrefServer = new OsServer();
		ossPrefServer.setName("SERVER");
		ossPrefServer.setTypeclass("SERVER");
		ossPrefServer.setState("YETTOSTART");
		ossPrefServer.setStatus("S");
		ossPrefServer.setAppservertype(propertiesObj.getObjJenkinsProp().getServerType());
		ossPrefServer.setAdmindbtype(propertiesObj.getObjJenkinsProp().getDBType());//Need to check for the ORACLE
		ossPrefServer.setAppdbtype(propertiesObj.getObjJenkinsProp().getDBType());
		ossPrefServer.setWarfilename(propertiesObj.getObjJenkinsProp().getServerWarName());
		String serverUrl = "";
		List<Environmentvariablefile> environmentFileList = environment.getEnvironmentvariablefile();
		if (null != environmentFileList) {
			for (int i = 0; i < environmentFileList.size(); i++) {
				if (environmentFileList.get(i).getKeyname().equalsIgnoreCase("APPZILLONSERVER")) {
					serverUrl = environmentFileList.get(i).getValue();
				}
			}
			ossPrefServer.setServerurl(serverUrl);
		} else {
			ossPrefServer.setServerurl(baseApp.getServerurl());
		}
		ossPrefServer.setLogpath(serverPreference.getLogpath());
		ossPrefServer.setLogginglevel(propertiesObj.getObjJenkinsProp().getServerDebugLevel());//Make it dynamic
		ossPrefServer.setBundleserverprops(propertiesObj.getObjJenkinsProp().getBundleServerProps());
		ossPrefServer.setGenconvhtml("N");
		ossPrefServer.setMetadatadsn(serverPreference.getMetadatadsn());
		ossPrefServer.setAdmindsn(serverPreference.getAdmindsn());
		ossPrefServer.setStaticanalyzer(false);
		ossPrefServer.setEnablemonitoring(false);
		ossPrefServer.setHttpkeystorepath(serverPreference.getKeystorepath());
		ossPrefServer.setHttpkeystorepwd(serverPreference.getKeystorepwd());
		ossPrefServer.setHttpkeypwd(serverPreference.getKeypassword());
		ossPrefServer.setTruststorepath(serverPreference.getTruststorepath());
		ossPrefServer.setTruststorepwd(serverPreference.getTruststorepwd());
		ossPrefServer.setSmsport(serverPreference.getSmsport());
		ossPrefServer.setDevicedestinationport(serverPreference.getDevicedestinationport());
		ossPrefServer.setPrivateKey(serverPreference.getPrivatekey());
		//new change
		ossPrefServer.setTypeoflogging(serverPreference.getTypeoflogging());
		ossPrefServer.setRolloverlog(serverPreference.getRolloverlog());
		ossPrefServer.setLogfilemaxsize(serverPreference.getLogfilemaxsize());
		ossPrefServer.setDefrolloverstrategy(serverPreference.getDefrolloverstrategy());
		ossPrefServer.setKafkatopic("");
		ossPrefServer.setKafkaservers(serverPreference.getKafkaservers());
		ossPrefServer.setMaxramalloc(serverPreference.getMaxramalloc());
		ossPrefServer.setRecordbatchsize(serverPreference.getRecordbatchsize());
		ossPrefServer.setMultitenancy(serverPreference.getMultitenancy());
		ossServer.add(ossPrefServer);
		return ossServer;
	}
	
	public static void fileOperationHandler (File file,String mode){
		try{
			if(mode.equalsIgnoreCase(FILE_DELETE)){
				if(file.delete()){
					String filedata = file.toString();
					LOG.info(filedata);
				}else LOG.info("File exist");

			}else if(mode.equalsIgnoreCase(FILE_CREATE)){
				if (file.createNewFile())
				{
					LOG.info("File is created!");
				} else LOG.info("File already exists.");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
