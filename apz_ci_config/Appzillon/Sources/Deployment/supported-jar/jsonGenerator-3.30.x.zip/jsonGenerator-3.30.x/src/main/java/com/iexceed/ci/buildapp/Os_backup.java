
package com.iexceed.ci.buildapp;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "name",
    "typeclass",
    "state",
    "status",
    "buildmode",
    "warfilename",
    "logdir",
    "settingspath",
    "httpkeystorepath",
    "keystorepassword",
    "truststorepath",
    "bundlewebprops",
    "httponlycookie",
    "securecookie",
    "csrfprevention",
    "safekey",
    "truststorepwd"
})
public class Os_backup {

    @JsonProperty("name")
    private String name;
    @JsonProperty("typeclass")
    private String typeclass;
    @JsonProperty("state")
    private String state;
    @JsonProperty("status")
    private String status;
    @JsonProperty("buildmode")
    private String buildmode;
    @JsonProperty("warfilename")
    private String warfilename;
    @JsonProperty("logdir")
    private String logdir;
    @JsonProperty("settingspath")
    private String settingspath;
    @JsonProperty("httpkeystorepath")
    private String httpkeystorepath;
    @JsonProperty("keystorepassword")
    private String keystorepassword;
    @JsonProperty("truststorepath")
    private String truststorepath;
    @JsonProperty("bundlewebprops")
    private String bundlewebprops;
    @JsonProperty("httponlycookie")
    private String httponlycookie;
    @JsonProperty("securecookie")
    private String securecookie;
    @JsonProperty("csrfprevention")
    private String csrfprevention;
    @JsonProperty("safekey")
    private String safekey;
    @JsonProperty("truststorepwd")
    private String truststorepwd;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("typeclass")
    public String getTypeclass() {
        return typeclass;
    }

    @JsonProperty("typeclass")
    public void setTypeclass(String typeclass) {
        this.typeclass = typeclass;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("buildmode")
    public String getBuildmode() {
        return buildmode;
    }

    @JsonProperty("buildmode")
    public void setBuildmode(String buildmode) {
        this.buildmode = buildmode;
    }

    @JsonProperty("warfilename")
    public String getWarfilename() {
        return warfilename;
    }

    @JsonProperty("warfilename")
    public void setWarfilename(String warfilename) {
        this.warfilename = warfilename;
    }

    @JsonProperty("logdir")
    public String getLogdir() {
        return logdir;
    }

    @JsonProperty("logdir")
    public void setLogdir(String logdir) {
        this.logdir = logdir;
    }

    @JsonProperty("settingspath")
    public String getSettingspath() {
        return settingspath;
    }

    @JsonProperty("settingspath")
    public void setSettingspath(String settingspath) {
        this.settingspath = settingspath;
    }

    @JsonProperty("httpkeystorepath")
    public String getHttpkeystorepath() {
        return httpkeystorepath;
    }

    @JsonProperty("httpkeystorepath")
    public void setHttpkeystorepath(String httpkeystorepath) {
        this.httpkeystorepath = httpkeystorepath;
    }

    @JsonProperty("keystorepassword")
    public String getKeystorepassword() {
        return keystorepassword;
    }

    @JsonProperty("keystorepassword")
    public void setKeystorepassword(String keystorepassword) {
        this.keystorepassword = keystorepassword;
    }

    @JsonProperty("truststorepath")
    public String getTruststorepath() {
        return truststorepath;
    }

    @JsonProperty("truststorepath")
    public void setTruststorepath(String truststorepath) {
        this.truststorepath = truststorepath;
    }

    @JsonProperty("bundlewebprops")
    public String getBundlewebprops() {
        return bundlewebprops;
    }

    @JsonProperty("bundlewebprops")
    public void setBundlewebprops(String bundlewebprops) {
        this.bundlewebprops = bundlewebprops;
    }

    @JsonProperty("httponlycookie")
    public String getHttponlycookie() {
        return httponlycookie;
    }

    @JsonProperty("httponlycookie")
    public void setHttponlycookie(String httponlycookie) {
        this.httponlycookie = httponlycookie;
    }

    @JsonProperty("securecookie")
    public String getSecurecookie() {
        return securecookie;
    }

    @JsonProperty("securecookie")
    public void setSecurecookie(String securecookie) {
        this.securecookie = securecookie;
    }

    @JsonProperty("csrfprevention")
    public String getCsrfprevention() {
        return csrfprevention;
    }

    @JsonProperty("csrfprevention")
    public void setCsrfprevention(String csrfprevention) {
        this.csrfprevention = csrfprevention;
    }

    @JsonProperty("safekey")
    public String getSafekey() {
        return safekey;
    }

    @JsonProperty("safekey")
    public void setSafekey(String safekey) {
        this.safekey = safekey;
    }

    @JsonProperty("truststorepwd")
    public String getTruststorepwd() {
        return truststorepwd;
    }

    @JsonProperty("truststorepwd")
    public void setTruststorepwd(String truststorepwd) {
        this.truststorepwd = truststorepwd;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
